ORBIT SECURITY PHASE 1 — START HERE

GOAL
Before changing security settings, first capture the current state safely.

STEP 1 — BACKUP CHECK
1. Open Supabase.
2. Open the Orbit / Azhar CRM project.
3. Open the Backups section.
4. Confirm whether automatic backups are active.
5. Do NOT delete or restore anything.
6. Take a screenshot of the backup screen.

STEP 2 — RUN THE READ-ONLY AUDIT
1. Open Supabase → SQL Editor.
2. Create a new query.
3. Open 01_orbit_security_audit_read_only.sql from this pack.
4. Paste the entire script.
5. Run it.
6. This script is READ-ONLY. It contains no schema/data modification statements.
7. Save/export the results or take screenshots.

STEP 3 — SEND THE RESULTS BACK TO CHATGPT
Share screenshots or the exported result.
We will classify findings as:
- CRITICAL
- HIGH
- MEDIUM
- GOOD / already protected

STEP 4 — ONLY THEN APPLY FIXES
The next Orbit security pack will contain targeted SQL and code changes based on the real audit.

DO NOT RELEASE PARENT/STUDENT ACCESS YET
until we confirm:
- Student A cannot see Student B
- Parent A cannot see Parent B's child
- Trainer A cannot see unrelated batches
- Sales cannot see restricted finance data
- Normal employees cannot access admin/security functions
