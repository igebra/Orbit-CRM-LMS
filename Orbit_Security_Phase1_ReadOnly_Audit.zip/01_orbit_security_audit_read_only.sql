-- ============================================================
-- ORBIT SECURITY PHASE 1 — READ-ONLY AUDIT
-- SAFE TO RUN: YES
-- CHANGES DATA/SCHEMA: NO
-- PURPOSE: Inventory RLS, policies, grants, roles, audit coverage
-- ============================================================

-- 1) PUBLIC TABLES + RLS STATUS
select
  n.nspname as schema_name,
  c.relname as table_name,
  c.relrowsecurity as rls_enabled,
  c.relforcerowsecurity as rls_forced
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'r'
  and n.nspname = 'public'
order by c.relname;

-- 2) PUBLIC TABLES WITH RLS OFF
select
  c.relname as table_without_rls
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'r'
  and n.nspname = 'public'
  and c.relrowsecurity = false
order by c.relname;

-- 3) ALL RLS POLICIES
select
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
from pg_policies
where schemaname = 'public'
order by tablename, cmd, policyname;

-- 4) TABLE GRANTS TO ANON / AUTHENTICATED
select
  table_schema,
  table_name,
  grantee,
  privilege_type
from information_schema.role_table_grants
where table_schema = 'public'
  and grantee in ('anon', 'authenticated')
order by table_name, grantee, privilege_type;

-- 5) SECURITY DEFINER FUNCTIONS
select
  n.nspname as schema_name,
  p.proname as function_name,
  pg_get_function_identity_arguments(p.oid) as arguments,
  p.prosecdef as security_definer,
  pg_get_userbyid(p.proowner) as owner
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.prosecdef = true
order by p.proname;

-- 6) FUNCTION EXECUTE PRIVILEGES
select
  routine_schema,
  routine_name,
  grantee,
  privilege_type
from information_schema.routine_privileges
where routine_schema = 'public'
  and grantee in ('anon', 'authenticated')
order by routine_name, grantee;

-- 7) POSSIBLY BROAD POLICIES
select
  tablename,
  policyname,
  cmd,
  roles,
  qual,
  with_check
from pg_policies
where schemaname = 'public'
  and (
    lower(coalesce(qual, '')) in ('true', '(true)')
    or lower(coalesce(with_check, '')) in ('true', '(true)')
  )
order by tablename, policyname;

-- 8) STORAGE BUCKET VISIBILITY
select
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
from storage.buckets
order by name;

-- 9) STORAGE OBJECT POLICIES
select
  schemaname,
  tablename,
  policyname,
  roles,
  cmd,
  qual,
  with_check
from pg_policies
where schemaname = 'storage'
order by tablename, cmd, policyname;

-- 10) ORBIT ROLE DISTRIBUTION — COUNTS ONLY
select
  role,
  count(*) as user_count
from public.user_profiles
group by role
order by role;

-- 11) AUTH USERS WITHOUT ORBIT PROFILE — COUNT ONLY
select
  count(*) as auth_users_without_profile
from auth.users u
left join public.user_profiles p on p.id = u.id
where p.id is null;

-- 12) AUDIT / RECYCLE TABLES PRESENT?
select
  to_regclass('public.orbit_audit_log') as audit_log_table,
  to_regclass('public.orbit_recycle_bin') as recycle_bin_table;

-- 13) AUDIT TRIGGER COVERAGE
select
  event_object_table as table_name,
  trigger_name,
  event_manipulation as event,
  action_timing
from information_schema.triggers
where trigger_schema = 'public'
  and (
    lower(trigger_name) like '%audit%'
    or lower(action_statement) like '%audit%'
  )
order by table_name, trigger_name, event;

-- 14) TABLES WITHOUT ANY RLS POLICY
with public_tables as (
  select c.relname as table_name, c.relrowsecurity
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where c.relkind = 'r' and n.nspname = 'public'
),
policy_counts as (
  select tablename, count(*) as policy_count
  from pg_policies
  where schemaname = 'public'
  group by tablename
)
select
  t.table_name,
  t.relrowsecurity as rls_enabled,
  coalesce(p.policy_count, 0) as policy_count
from public_tables t
left join policy_counts p on p.tablename = t.table_name
where coalesce(p.policy_count, 0) = 0
order by t.table_name;

-- ============================================================
-- END OF READ-ONLY AUDIT
-- ============================================================
