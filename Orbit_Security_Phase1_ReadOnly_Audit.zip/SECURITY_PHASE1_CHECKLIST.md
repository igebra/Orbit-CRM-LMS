# Orbit Security Phase 1 Checklist

## Backup & Recovery
- [ ] Confirm database backup status
- [ ] Confirm private GitHub repository
- [ ] Record current production deployment
- [ ] Define who may restore backups
- [ ] Schedule a restore test

## Database Security
- [ ] Inventory public tables
- [ ] Confirm RLS
- [ ] Review RLS policies
- [ ] Review anon/authenticated grants
- [ ] Review SECURITY DEFINER functions
- [ ] Review storage bucket privacy
- [ ] Confirm audit-log coverage
- [ ] Confirm recycle-bin/recovery coverage

## Identity & Permissions
- [ ] Finalize role matrix
- [ ] Individual employee accounts only
- [ ] No shared admin credentials
- [ ] MFA for privileged staff
- [ ] Student isolation test
- [ ] Parent isolation test
- [ ] Trainer isolation test

## Application / Vercel
- [ ] Add security headers / CSP
- [ ] Protect preview deployments
- [ ] Add rate limiting to sensitive endpoints
- [ ] Review runtime errors/logging
- [ ] Separate preview/test from production

## GitHub
- [ ] Private repository
- [ ] Protect main branch
- [ ] Pull-request workflow
- [ ] No secrets in repository
- [ ] Dependency scanning

## Privacy
- [ ] Data minimisation
- [ ] Privacy notice
- [ ] Data retention policy
- [ ] Employee offboarding process
