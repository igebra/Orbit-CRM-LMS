-- ============================================================
-- ORBIT — STUDENT + PARENT PORTALS
-- ============================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- 0. Ensure Orbit role validation includes Parent + Student
-- ------------------------------------------------------------
do $$
declare
  r record;
begin
  for r in
    select c.conname
    from pg_constraint c
    where c.conrelid = 'public.user_profiles'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) ilike '%role%'
  loop
    execute format(
      'alter table public.user_profiles drop constraint %I',
      r.conname
    );
  end loop;
end
$$;

alter table public.user_profiles
  drop constraint if exists orbit_user_profiles_role_check;

alter table public.user_profiles
  add constraint orbit_user_profiles_role_check
  check (
    role in (
      'super_admin',
      'admin',
      'sales',
      'sales_marketing',
      'marketing',
      'trainer',
      'accounts_finance',
      'viewer_management',
      'parent',
      'student'
    )
  );

-- ------------------------------------------------------------
-- 1. LMS content visibility
-- ------------------------------------------------------------
alter table public.lms_resources
  add column if not exists visibility text not null default 'Internal Only';

alter table public.lms_resources
  drop constraint if exists lms_resources_visibility_check;

alter table public.lms_resources
  add constraint lms_resources_visibility_check
  check (
    visibility in (
      'Internal Only',
      'Student',
      'Parent & Student'
    )
  );

-- ------------------------------------------------------------
-- 2. Portal access grants
-- ------------------------------------------------------------
create table if not exists public.portal_access_grants (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  access_type text not null
    check (access_type in ('student','parent')),
  full_name text,
  email text not null,
  relationship text,
  user_id uuid references auth.users(id) on delete set null,
  is_active boolean not null default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  activated_at timestamptz,
  unique(student_id,email,access_type)
);

create index if not exists portal_access_email_idx
  on public.portal_access_grants(lower(email));

create index if not exists portal_access_user_idx
  on public.portal_access_grants(user_id,student_id);

create unique index if not exists portal_one_student_login_per_student
  on public.portal_access_grants(student_id)
  where access_type='student' and is_active=true;

alter table public.portal_access_grants enable row level security;

-- ------------------------------------------------------------
-- 3. Helpers
-- ------------------------------------------------------------
create or replace function public.is_portal_access_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in ('super_admin','admin'),
    false
  );
$$;

grant execute on function public.is_portal_access_admin()
to authenticated;

create or replace function public.portal_can_access_student(
  p_student_id uuid,
  p_access_type text default null
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.portal_access_grants g
    where g.student_id = p_student_id
      and g.user_id = auth.uid()
      and g.is_active = true
      and (
        p_access_type is null
        or g.access_type = p_access_type
      )
  );
$$;

grant execute on function public.portal_can_access_student(uuid,text)
to authenticated;

-- ------------------------------------------------------------
-- 4. Admin: grant / revoke / list
-- ------------------------------------------------------------
create or replace function public.grant_portal_access(
  p_student_id uuid,
  p_email text,
  p_access_type text,
  p_full_name text default null,
  p_relationship text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_email text := lower(trim(p_email));
  v_id uuid;
  v_existing_user uuid;
  v_existing_role text;
begin
  if not public.is_portal_access_admin() then
    raise exception 'Only Super Admin or Admin can grant portal access.';
  end if;

  if p_access_type not in ('student','parent') then
    raise exception 'Access type must be student or parent.';
  end if;

  if nullif(v_email,'') is null then
    raise exception 'Email is required.';
  end if;

  if not exists (
    select 1 from public.students s where s.id = p_student_id
  ) then
    raise exception 'Student profile not found.';
  end if;

  select up.id, up.role
    into v_existing_user, v_existing_role
  from public.user_profiles up
  where lower(coalesce(up.email,'')) = v_email
  limit 1;

  if v_existing_user is not null
     and coalesce(v_existing_role,'') not in ('student','parent') then
    raise exception 'This email already belongs to an internal Orbit user.';
  end if;

  if p_access_type = 'student' then
    update public.portal_access_grants
    set is_active = false
    where student_id = p_student_id
      and access_type = 'student'
      and is_active = true
      and lower(email) <> v_email;
  end if;

  insert into public.portal_access_grants (
    student_id,
    access_type,
    full_name,
    email,
    relationship,
    user_id,
    is_active,
    created_by,
    activated_at
  )
  values (
    p_student_id,
    p_access_type,
    nullif(trim(p_full_name),''),
    v_email,
    case
      when p_access_type='student' then 'Self'
      else coalesce(nullif(trim(p_relationship),''),'Parent / Guardian')
    end,
    v_existing_user,
    true,
    auth.uid(),
    case when v_existing_user is not null then now() else null end
  )
  on conflict (student_id,email,access_type)
  do update set
    full_name = excluded.full_name,
    relationship = excluded.relationship,
    user_id = coalesce(
      excluded.user_id,
      public.portal_access_grants.user_id
    ),
    is_active = true,
    activated_at = case
      when coalesce(
        excluded.user_id,
        public.portal_access_grants.user_id
      ) is not null
      then coalesce(public.portal_access_grants.activated_at, now())
      else null
    end
  returning id into v_id;

  if v_existing_user is not null then
    update public.user_profiles
    set
      role = p_access_type,
      is_active = true,
      updated_at = now()
    where id = v_existing_user;
  end if;

  return v_id;
end;
$$;

grant execute on function public.grant_portal_access(uuid,text,text,text,text)
to authenticated;

create or replace function public.revoke_portal_access(
  p_grant_id uuid
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
begin
  if not public.is_portal_access_admin() then
    raise exception 'Only Super Admin or Admin can remove portal access.';
  end if;

  select user_id
    into v_user_id
  from public.portal_access_grants
  where id = p_grant_id;

  update public.portal_access_grants
  set is_active = false
  where id = p_grant_id;

  if v_user_id is not null
     and not exists (
       select 1
       from public.portal_access_grants
       where user_id = v_user_id
         and is_active = true
     ) then
    update public.user_profiles
    set
      is_active = false,
      updated_at = now()
    where id = v_user_id
      and role in ('student','parent');
  end if;

  return true;
end;
$$;

grant execute on function public.revoke_portal_access(uuid)
to authenticated;

create or replace function public.portal_access_admin_list()
returns table (
  grant_id uuid,
  student_id uuid,
  student_name text,
  grade text,
  access_type text,
  full_name text,
  email text,
  relationship text,
  user_id uuid,
  activated_at timestamptz,
  is_active boolean,
  created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_portal_access_admin() then
    raise exception 'Access denied.';
  end if;

  return query
  select
    g.id,
    s.id,
    s.student_name,
    s.grade,
    g.access_type,
    g.full_name,
    g.email,
    g.relationship,
    g.user_id,
    g.activated_at,
    g.is_active,
    g.created_at
  from public.portal_access_grants g
  join public.students s on s.id = g.student_id
  where g.is_active = true
  order by s.student_name, g.access_type, g.created_at;
end;
$$;

grant execute on function public.portal_access_admin_list()
to authenticated;

-- ------------------------------------------------------------
-- 5. Activation
-- ------------------------------------------------------------
create or replace function public.portal_access_grant_exists(
  p_email text
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.portal_access_grants g
    where lower(g.email) = lower(trim(p_email))
      and g.is_active = true
  );
$$;

grant execute on function public.portal_access_grant_exists(text)
to anon, authenticated;

create or replace function public.activate_portal_access()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_email text;
  v_role text;
  v_name text;
begin
  if auth.uid() is null then
    return null;
  end if;

  select lower(email)
    into v_email
  from auth.users
  where id = auth.uid();

  if v_email is null then
    return null;
  end if;

  if exists (
    select 1
    from public.portal_access_grants
    where lower(email)=v_email
      and access_type='student'
      and is_active=true
  ) then
    v_role := 'student';

  elsif exists (
    select 1
    from public.portal_access_grants
    where lower(email)=v_email
      and access_type='parent'
      and is_active=true
  ) then
    v_role := 'parent';

  else
    return null;
  end if;

  select full_name
    into v_name
  from public.portal_access_grants
  where lower(email)=v_email
    and access_type=v_role
    and is_active=true
  order by created_at
  limit 1;

  insert into public.user_profiles (
    id,
    email,
    full_name,
    role,
    is_active,
    created_at,
    updated_at
  )
  values (
    auth.uid(),
    v_email,
    v_name,
    v_role,
    true,
    now(),
    now()
  )
  on conflict (id)
  do update set
    email = excluded.email,
    full_name = coalesce(
      excluded.full_name,
      public.user_profiles.full_name
    ),
    role = excluded.role,
    is_active = true,
    updated_at = now();

  update public.portal_access_grants
  set
    user_id = auth.uid(),
    activated_at = coalesce(activated_at, now())
  where lower(email)=v_email
    and access_type=v_role
    and is_active=true;

  return v_role;
end;
$$;

grant execute on function public.activate_portal_access()
to authenticated;

-- ------------------------------------------------------------
-- 6. Safe portal data
-- ------------------------------------------------------------
create or replace function public.portal_my_students()
returns table (
  student_id uuid,
  student_name text,
  grade text,
  access_type text,
  relationship text
)
language sql
stable
security definer
set search_path = public
as $$
  select
    s.id,
    s.student_name,
    s.grade,
    g.access_type,
    g.relationship
  from public.portal_access_grants g
  join public.students s on s.id = g.student_id
  where g.user_id = auth.uid()
    and g.is_active = true
  order by s.student_name;
$$;

grant execute on function public.portal_my_students()
to authenticated;

create or replace function public.portal_student_enrollments(
  p_student_id uuid
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if not public.portal_can_access_student(p_student_id,null) then
    raise exception 'Access denied.';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', e.id,
        'course_name', e.course_name,
        'status', e.status,
        'enrolled_at', e.enrolled_at,
        'completed_at', e.completed_at
      )
      order by e.created_at desc
    ),
    '[]'::jsonb
  )
  into v_result
  from public.student_enrollments e
  where e.student_id = p_student_id;

  return v_result;
end;
$$;

grant execute on function public.portal_student_enrollments(uuid)
to authenticated;

create or replace function public.portal_student_classes(
  p_student_id uuid
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if not public.portal_can_access_student(p_student_id,null) then
    raise exception 'Access denied.';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'session_id', cs.id,
        'batch_id', b.id,
        'batch_name', b.batch_name,
        'course_name', b.course_name,
        'session_number', cs.session_number,
        'session_date', cs.session_date,
        'scheduled_at', cs.scheduled_at,
        'topic_planned', cs.topic_planned,
        'topic_covered', cs.topic_covered,
        'status', cs.status,
        'trainer_name', cs.trainer_name,
        'zoom_meeting_url', cs.zoom_meeting_url,
        'zoom_recording_url',
          case
            when cs.status='Completed'
            then cs.zoom_recording_url
            else null
          end
      )
      order by
        coalesce(cs.scheduled_at, cs.session_date::timestamptz) desc
    ),
    '[]'::jsonb
  )
  into v_result
  from public.batch_students bs
  join public.batches b on b.id = bs.batch_id
  join public.class_sessions cs on cs.batch_id = b.id
  where bs.student_id = p_student_id;

  return v_result;
end;
$$;

grant execute on function public.portal_student_classes(uuid)
to authenticated;

create or replace function public.portal_student_progress(
  p_student_id uuid
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if not public.portal_can_access_student(p_student_id,null) then
    raise exception 'Access denied.';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'session_id', cs.id,
        'class_date', cs.session_date,
        'batch_name', b.batch_name,
        'course_name', b.course_name,
        'session_number', cs.session_number,
        'topic_covered', cs.topic_covered,
        'class_status', cs.status,
        'attendance_status', sa.attendance_status,
        'homework_completed', sh.homework_completed
      )
      order by
        cs.session_date desc,
        cs.session_number desc nulls last
    ),
    '[]'::jsonb
  )
  into v_result
  from public.batch_students bs
  join public.batches b on b.id = bs.batch_id
  join public.class_sessions cs on cs.batch_id = b.id
  left join public.session_attendance sa
    on sa.session_id = cs.id
   and sa.student_id = p_student_id
  left join public.session_homework sh
    on sh.session_id = cs.id
   and sh.student_id = p_student_id
  where bs.student_id = p_student_id;

  return v_result;
end;
$$;

grant execute on function public.portal_student_progress(uuid)
to authenticated;

create or replace function public.portal_parent_payments(
  p_student_id uuid
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if not public.portal_can_access_student(p_student_id,'parent') then
    raise exception 'Parent access required.';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'batch_id', p.batch_id,
        'batch_name', p.batch_name,
        'course_name', p.course_name,
        'total_fee_usd', p.total_fee_usd,
        'total_paid_usd', p.total_paid_usd,
        'pending_usd', p.pending_usd,
        'payment_status', p.payment_status,
        'next_due_date', p.next_due_date
      )
      order by p.batch_name
    ),
    '[]'::jsonb
  )
  into v_result
  from public.batch_student_payment_summary p
  where p.student_id = p_student_id;

  return v_result;
end;
$$;

grant execute on function public.portal_parent_payments(uuid)
to authenticated;

-- ------------------------------------------------------------
-- 7. Released resources
-- ------------------------------------------------------------
create or replace function public.portal_student_resources(
  p_student_id uuid,
  p_for_parent boolean default false
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if p_for_parent then
    if not public.portal_can_access_student(p_student_id,'parent') then
      raise exception 'Parent access required.';
    end if;
  else
    if not public.portal_can_access_student(p_student_id,'student') then
      raise exception 'Student access required.';
    end if;
  end if;

  select coalesce(
    jsonb_agg(
      item
      order by
        (item->>'class_date')::date desc,
        (item->>'session_number')::int desc
    ),
    '[]'::jsonb
  )
  into v_result
  from (
    select distinct on (lr.id)
      jsonb_build_object(
        'resource_id', lr.id,
        'course_name', b.course_name,
        'session_number', lc.session_number,
        'topic', lc.topic,
        'resource_type', lr.resource_type,
        'title', lr.title,
        'description', lr.description,
        'visibility', lr.visibility,
        'file_name', lv.file_name,
        'storage_path', lv.storage_path,
        'version_number', lv.version_number,
        'class_date', cs.session_date
      ) as item,
      lr.id as sort_id
    from public.batch_students bs
    join public.batches b
      on b.id = bs.batch_id
    join public.class_sessions cs
      on cs.batch_id = b.id
     and cs.status = 'Completed'
    join public.lms_curriculum_sessions lc
      on lc.course_name = b.course_name
     and lc.session_number = cs.session_number
    join public.lms_resources lr
      on lr.curriculum_session_id = lc.id
     and lr.is_archived = false
    join lateral (
      select v.*
      from public.lms_resource_versions v
      where v.resource_id = lr.id
      order by v.version_number desc
      limit 1
    ) lv on true
    where bs.student_id = p_student_id
      and (
        (
          p_for_parent = true
          and lr.visibility = 'Parent & Student'
        )
        or
        (
          p_for_parent = false
          and lr.visibility in ('Student','Parent & Student')
        )
      )
    order by lr.id, cs.session_date desc
  ) x;

  return v_result;
end;
$$;

grant execute on function public.portal_student_resources(uuid,boolean)
to authenticated;

-- ------------------------------------------------------------
-- 8. Storage entitlement
-- ------------------------------------------------------------
create or replace function public.portal_can_access_lms_resource(
  p_resource_id uuid
)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_role text;
begin
  select role
    into v_role
  from public.user_profiles
  where id = auth.uid()
    and is_active = true;

  if v_role not in ('student','parent') then
    return false;
  end if;

  return exists (
    select 1
    from public.portal_access_grants g
    join public.batch_students bs
      on bs.student_id = g.student_id
    join public.batches b
      on b.id = bs.batch_id
    join public.class_sessions cs
      on cs.batch_id = b.id
     and cs.status = 'Completed'
    join public.lms_curriculum_sessions lc
      on lc.course_name = b.course_name
     and lc.session_number = cs.session_number
    join public.lms_resources lr
      on lr.curriculum_session_id = lc.id
     and lr.id = p_resource_id
     and lr.is_archived = false
    where g.user_id = auth.uid()
      and g.is_active = true
      and (
        (
          v_role='student'
          and g.access_type='student'
          and lr.visibility in ('Student','Parent & Student')
        )
        or
        (
          v_role='parent'
          and g.access_type='parent'
          and lr.visibility='Parent & Student'
        )
      )
  );
end;
$$;

grant execute on function public.portal_can_access_lms_resource(uuid)
to authenticated;

create or replace function public.portal_can_access_lms_storage_path(
  p_name text
)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_resource_id uuid;
begin
  begin
    v_resource_id := split_part(p_name,'/',1)::uuid;
  exception
    when others then
      return false;
  end;

  return public.portal_can_access_lms_resource(v_resource_id);
end;
$$;

grant execute on function public.portal_can_access_lms_storage_path(text)
to authenticated;

drop policy if exists "Portal LMS library read" on storage.objects;

create policy "Portal LMS library read"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'lms-library'
  and public.portal_can_access_lms_storage_path(name)
);

-- ============================================================
-- END
-- ============================================================
