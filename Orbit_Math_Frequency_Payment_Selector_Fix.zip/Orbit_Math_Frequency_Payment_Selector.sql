-- ORBIT MATH FREQUENCY + PAYMENT SELECTOR
-- Additive only. Does not touch CRM leads.

alter table public.batches
  add column if not exists classes_per_week integer not null default 1;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname='batches_classes_per_week_check'
  ) then
    alter table public.batches
      add constraint batches_classes_per_week_check
      check (classes_per_week between 1 and 7);
  end if;
end
$$;

create or replace function public.payment_entry_options()
returns table(
  batch_id uuid,
  batch_name text,
  course_name text,
  student_id uuid,
  student_name text,
  finance_id uuid,
  total_fee_usd numeric,
  payment_plan text,
  installment_amount_usd numeric,
  total_paid_usd numeric,
  pending_usd numeric
)
language plpgsql
stable
security definer
set search_path=public
as $$
begin
  if not public.can_view_finance() then
    raise exception 'You do not have permission to view payment options.';
  end if;

  return query
  select
    b.id,
    b.batch_name,
    b.course_name,
    s.id,
    s.student_name,
    f.id,
    f.total_fee_usd,
    f.payment_plan,
    f.installment_amount_usd,
    coalesce(p.paid,0)::numeric,
    case
      when f.id is null then null
      else greatest(coalesce(f.total_fee_usd,0)-coalesce(p.paid,0),0)
    end::numeric
  from public.batch_students bs
  join public.batches b on b.id=bs.batch_id
  join public.students s on s.id=bs.student_id
  left join public.batch_student_finance f
    on f.batch_id=bs.batch_id and f.student_id=bs.student_id
  left join lateral (
    select coalesce(sum(pt.amount_usd),0)::numeric as paid
    from public.payment_transactions pt
    where pt.finance_id=f.id
  ) p on true
  where coalesce(b.status,'Active') <> 'Archived'
  order by b.batch_name,s.student_name;
end;
$$;

grant execute on function public.payment_entry_options() to authenticated;

create or replace function public.ensure_payment_plan_for_entry(
  p_batch_id uuid,
  p_student_id uuid,
  p_total_fee_usd numeric,
  p_payment_plan text,
  p_installment_amount_usd numeric,
  p_plan_start_date date
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role text;
  v_id uuid;
begin
  select role into v_role
  from public.user_profiles
  where id=auth.uid();

  if v_role not in (
    'super_admin','admin','sales','sales_marketing','accounts_finance'
  ) then
    raise exception 'You do not have permission to configure payment plans.';
  end if;

  if not exists(
    select 1 from public.batch_students
    where batch_id=p_batch_id and student_id=p_student_id
  ) then
    raise exception 'This student is not assigned to this batch.';
  end if;

  if p_total_fee_usd is null or p_total_fee_usd<=0 then
    raise exception 'Total fee must be greater than zero.';
  end if;

  if p_installment_amount_usd is null or p_installment_amount_usd<=0 then
    raise exception 'Installment amount must be greater than zero.';
  end if;

  if p_payment_plan not in (
    'After Every 4 Classes','Monthly','Quarterly',
    'Half-yearly','Yearly','Custom'
  ) then
    raise exception 'Invalid payment plan.';
  end if;

  insert into public.batch_student_finance(
    batch_id,student_id,total_fee_usd,payment_plan,
    installment_amount_usd,plan_start_date,created_by,updated_by
  )
  values(
    p_batch_id,p_student_id,p_total_fee_usd,p_payment_plan,
    p_installment_amount_usd,p_plan_start_date,auth.uid(),auth.uid()
  )
  on conflict(batch_id,student_id)
  do update set
    total_fee_usd=excluded.total_fee_usd,
    payment_plan=excluded.payment_plan,
    installment_amount_usd=excluded.installment_amount_usd,
    plan_start_date=excluded.plan_start_date,
    updated_by=auth.uid()
  returning id into v_id;

  return v_id;
end;
$$;

grant execute on function public.ensure_payment_plan_for_entry(
  uuid,uuid,numeric,text,numeric,date
) to authenticated;
