-- ============================================================
-- ORBIT — LMS FINAL COMPLETE
-- Internal delivery/operations LMS for igebra.ai
-- ============================================================

-- ------------------------------------------------------------
-- 1. FINAL ROLE HELPERS
-- ------------------------------------------------------------
create or replace function public.is_lms_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing'
    ),
    false
  );
$$;

create or replace function public.can_view_lms()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing',
      'marketing','accounts_finance','viewer_management'
    ),
    false
  );
$$;

create or replace function public.can_view_batch(p_batch_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    public.is_lms_admin()
    or coalesce(
      public.current_orbit_role() in (
        'marketing','accounts_finance','viewer_management'
      ),
      false
    )
    or public.trainer_can_access_batch(p_batch_id);
$$;

create or replace function public.can_teach_batch(p_batch_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    public.is_lms_admin()
    or public.trainer_can_access_batch(p_batch_id);
$$;

create or replace function public.can_view_student(p_student_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    public.is_lms_admin()
    or coalesce(
      public.current_orbit_role() in (
        'marketing','accounts_finance','viewer_management'
      ),
      false
    )
    or exists (
      select 1
      from public.batch_students bs
      where bs.student_id = p_student_id
        and public.trainer_can_access_batch(bs.batch_id)
    );
$$;

-- ------------------------------------------------------------
-- 2. OPERATIONAL LMS FIELDS
-- ------------------------------------------------------------
alter table public.batches
  add column if not exists default_duration_minutes integer not null default 90;

alter table public.batches
  drop constraint if exists batches_default_duration_minutes_check;

alter table public.batches
  add constraint batches_default_duration_minutes_check
  check (default_duration_minutes in (60,90,120));

alter table public.class_sessions
  add column if not exists scheduled_at timestamptz;

alter table public.class_sessions
  add column if not exists source_timezone text;

alter table public.class_sessions
  add column if not exists duration_minutes integer not null default 90;

alter table public.class_sessions
  drop constraint if exists class_sessions_duration_minutes_check;

alter table public.class_sessions
  add constraint class_sessions_duration_minutes_check
  check (duration_minutes in (60,90,120));

alter table public.student_enrollments
  add column if not exists updated_by uuid references auth.users(id) on delete set null;

alter table public.student_enrollments
  add column if not exists updated_at timestamptz not null default now();

alter table public.session_attendance
  add column if not exists marked_by uuid references auth.users(id) on delete set null;

alter table public.session_attendance
  add column if not exists marked_at timestamptz;

create index if not exists class_sessions_scheduled_at_idx
  on public.class_sessions(scheduled_at);

drop trigger if exists set_student_enrollments_updated_at
on public.student_enrollments;

create trigger set_student_enrollments_updated_at
before update on public.student_enrollments
for each row execute function public.set_updated_at();

-- Course-aware defaults.
update public.batches
set
  planned_sessions = coalesce(planned_sessions,20),
  default_duration_minutes = 90
where
  lower(course_name) like 'aiedge%'
  or lower(course_name) like 'coding4ai%';

update public.batches
set default_duration_minutes = 60
where
  lower(course_name) like 'math%'
  or lower(course_name) like 'ap %'
  or lower(course_name) like 'sat%'
  or lower(course_name) like 'algebra%'
  or lower(course_name) like 'geometry%';

-- Keep old sessions usable without inventing a class time.
update public.class_sessions cs
set
  source_timezone = coalesce(cs.source_timezone,b.source_timezone,'Asia/Kolkata'),
  duration_minutes = coalesce(cs.duration_minutes,b.default_duration_minutes,90)
from public.batches b
where cs.batch_id = b.id
  and (cs.source_timezone is null or cs.duration_minutes is null);

-- ------------------------------------------------------------
-- 3. TRAINER DIRECTORY IDENTITY + HISTORY
-- ------------------------------------------------------------
create or replace function public.sync_batch_trainer_identity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name text;
  v_user_id uuid;
begin
  if tg_op = 'INSERT' then
    if new.trainer_id is null then
      new.trainer_name := null;
      new.trainer_user_id := null;
      return new;
    end if;

    select trainer_name, linked_user_id
    into v_name, v_user_id
    from public.trainers
    where id = new.trainer_id
      and status = 'Active';

    if v_name is null then
      raise exception 'Trainer not found or inactive.';
    end if;

    new.trainer_name := v_name;
    new.trainer_user_id := v_user_id;
    return new;
  end if;

  if new.trainer_id is null
     and old.trainer_id is distinct from new.trainer_id then
    new.trainer_name := null;
    new.trainer_user_id := null;
    return new;
  end if;

  if old.trainer_id is distinct from new.trainer_id then
    select trainer_name, linked_user_id
    into v_name, v_user_id
    from public.trainers
    where id = new.trainer_id
      and status = 'Active';

    if v_name is null then
      raise exception 'Trainer not found or inactive.';
    end if;

    new.trainer_name := v_name;
    new.trainer_user_id := v_user_id;
  end if;

  return new;
end;
$$;

drop trigger if exists sync_batch_trainer_identity_trigger
on public.batches;

create trigger sync_batch_trainer_identity_trigger
before insert or update of trainer_id
on public.batches
for each row
execute function public.sync_batch_trainer_identity();

create or replace function public.sync_batch_trainer_history()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    if new.trainer_id is not null
       or nullif(trim(coalesce(new.trainer_name,'')), '') is not null then
      insert into public.batch_trainer_assignments (
        batch_id,
        trainer_id,
        trainer_user_id,
        trainer_name,
        assigned_from,
        is_active,
        changed_by
      )
      values (
        new.id,
        new.trainer_id,
        new.trainer_user_id,
        new.trainer_name,
        coalesce(new.start_date,current_date),
        true,
        new.updated_by
      )
      on conflict do nothing;
    end if;

    return new;
  end if;

  if old.trainer_id is distinct from new.trainer_id
     or old.trainer_name is distinct from new.trainer_name then

    update public.batch_trainer_assignments
    set
      is_active = false,
      assigned_to = current_date
    where batch_id = new.id
      and is_active = true;

    if new.trainer_id is not null
       or nullif(trim(coalesce(new.trainer_name,'')), '') is not null then
      insert into public.batch_trainer_assignments (
        batch_id,
        trainer_id,
        trainer_user_id,
        trainer_name,
        assigned_from,
        is_active,
        changed_by
      )
      values (
        new.id,
        new.trainer_id,
        new.trainer_user_id,
        new.trainer_name,
        current_date,
        true,
        new.updated_by
      );
    end if;

    -- Critical: completed class history is never overwritten.
    update public.class_sessions
    set
      trainer_id = new.trainer_id,
      trainer_user_id = new.trainer_user_id,
      trainer_name = new.trainer_name,
      updated_by = new.updated_by
    where batch_id = new.id
      and status <> 'Completed'
      and session_date >= current_date;
  end if;

  return new;
end;
$$;

drop trigger if exists sync_batch_trainer_history_trigger
on public.batches;

create trigger sync_batch_trainer_history_trigger
after insert or update of trainer_id, trainer_name
on public.batches
for each row
execute function public.sync_batch_trainer_history();

-- ------------------------------------------------------------
-- 4. SAFE BATCH ROSTER HELPERS
-- ------------------------------------------------------------
create or replace function public.add_student_to_batch(
  p_batch_id uuid,
  p_student_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_max integer;
  v_count integer;
begin
  if not public.is_lms_admin() then
    raise exception 'You do not have permission to change the batch roster.';
  end if;

  select max_students into v_max
  from public.batches
  where id = p_batch_id;

  if v_max is null then
    raise exception 'Batch not found.';
  end if;

  if not exists (
    select 1 from public.students
    where id = p_student_id
      and status = 'Active'
  ) then
    raise exception 'Student not found or inactive.';
  end if;

  if exists (
    select 1
    from public.batch_students
    where batch_id = p_batch_id
      and student_id = p_student_id
  ) then
    return;
  end if;

  select count(*) into v_count
  from public.batch_students
  where batch_id = p_batch_id;

  if v_count >= coalesce(v_max,8) then
    raise exception
      'This batch already has the maximum of % students.',
      coalesce(v_max,8);
  end if;

  insert into public.batch_students(batch_id,student_id)
  values (p_batch_id,p_student_id);
end;
$$;

grant execute on function public.add_student_to_batch(uuid,uuid)
to authenticated;

create or replace function public.remove_student_from_batch(
  p_batch_id uuid,
  p_student_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_lms_admin() then
    raise exception 'You do not have permission to change the batch roster.';
  end if;

  delete from public.batch_students
  where batch_id = p_batch_id
    and student_id = p_student_id;
end;
$$;

grant execute on function public.remove_student_from_batch(uuid,uuid)
to authenticated;

-- ------------------------------------------------------------
-- 5. WEEKLY BATCH SCHEDULE GENERATOR
-- Preserves the same local class time across US DST changes.
-- Existing session numbers are skipped.
-- ------------------------------------------------------------
create or replace function public.generate_batch_sessions(
  p_batch_id uuid
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_batch public.batches%rowtype;
  v_local_start timestamp;
  v_local_class timestamp;
  v_scheduled timestamptz;
  v_i integer;
  v_inserted integer := 0;
begin
  if not public.is_lms_admin() then
    raise exception 'You do not have permission to generate the batch schedule.';
  end if;

  select * into v_batch
  from public.batches
  where id = p_batch_id;

  if not found then
    raise exception 'Batch not found.';
  end if;

  if v_batch.start_at is null then
    raise exception 'Batch Start Date & Time is required.';
  end if;

  if v_batch.planned_sessions is null
     or v_batch.planned_sessions < 1 then
    raise exception 'Planned Sessions must be set first.';
  end if;

  v_local_start :=
    v_batch.start_at at time zone
      coalesce(v_batch.source_timezone,'Asia/Kolkata');

  for v_i in 1..v_batch.planned_sessions loop
    if not exists (
      select 1
      from public.class_sessions
      where batch_id = p_batch_id
        and session_number = v_i
    ) then
      v_local_class :=
        v_local_start + make_interval(days => 7 * (v_i - 1));

      v_scheduled :=
        v_local_class at time zone
          coalesce(v_batch.source_timezone,'Asia/Kolkata');

      insert into public.class_sessions (
        batch_id,
        session_number,
        session_date,
        scheduled_at,
        source_timezone,
        duration_minutes,
        trainer_id,
        trainer_user_id,
        trainer_name,
        status,
        created_by,
        updated_by
      )
      values (
        p_batch_id,
        v_i,
        v_local_class::date,
        v_scheduled,
        coalesce(v_batch.source_timezone,'Asia/Kolkata'),
        coalesce(v_batch.default_duration_minutes,90),
        v_batch.trainer_id,
        v_batch.trainer_user_id,
        v_batch.trainer_name,
        'Scheduled',
        auth.uid(),
        auth.uid()
      );

      v_inserted := v_inserted + 1;
    end if;
  end loop;

  return v_inserted;
end;
$$;

grant execute on function public.generate_batch_sessions(uuid)
to authenticated;

-- ------------------------------------------------------------
-- 6. ATTENDANCE WITH AUDIT
-- ------------------------------------------------------------
create or replace function public.can_mark_attendance(
  p_batch_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    public.is_lms_admin()
    or public.trainer_can_access_batch(p_batch_id);
$$;

create or replace function public.save_session_attendance(
  p_session_id uuid,
  p_attendance jsonb
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_batch_id uuid;
  v_item jsonb;
  v_student_id uuid;
  v_status text;
begin
  select batch_id into v_batch_id
  from public.class_sessions
  where id = p_session_id;

  if v_batch_id is null then
    raise exception 'Session not found.';
  end if;

  if not public.can_mark_attendance(v_batch_id) then
    raise exception 'You do not have permission to mark attendance.';
  end if;

  for v_item in
    select * from jsonb_array_elements(p_attendance)
  loop
    v_student_id := (v_item->>'student_id')::uuid;
    v_status := v_item->>'attendance_status';

    if v_status not in ('Present','Absent','Late','Excused') then
      raise exception 'Invalid attendance status.';
    end if;

    if not exists (
      select 1
      from public.batch_students
      where batch_id = v_batch_id
        and student_id = v_student_id
    ) then
      raise exception 'Student is not assigned to this batch.';
    end if;

    insert into public.session_attendance (
      session_id,
      student_id,
      attendance_status,
      updated_by,
      updated_at,
      marked_by,
      marked_at
    )
    values (
      p_session_id,
      v_student_id,
      v_status,
      auth.uid(),
      now(),
      auth.uid(),
      now()
    )
    on conflict (session_id,student_id)
    do update set
      attendance_status = excluded.attendance_status,
      updated_by = auth.uid(),
      updated_at = now(),
      marked_by = auth.uid(),
      marked_at = now();
  end loop;
end;
$$;

grant execute on function public.save_session_attendance(uuid,jsonb)
to authenticated;

-- ------------------------------------------------------------
-- 7. REPORTS
-- ------------------------------------------------------------
create or replace function public.trainer_class_report(
  p_trainer_id uuid,
  p_from date,
  p_to date
)
returns table (
  session_id uuid,
  class_date date,
  batch_name text,
  course_name text,
  session_number integer,
  topic_covered text,
  session_status text,
  students_present integer,
  attendance_marked integer
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.can_view_lms() then
    raise exception 'You do not have permission to view LMS reports.';
  end if;

  return query
  select
    cs.id,
    cs.session_date,
    b.batch_name,
    b.course_name,
    cs.session_number,
    cs.topic_covered,
    cs.status,
    count(sa.id) filter (
      where sa.attendance_status in ('Present','Late')
    )::integer,
    count(sa.id)::integer
  from public.class_sessions cs
  join public.batches b
    on b.id = cs.batch_id
  left join public.session_attendance sa
    on sa.session_id = cs.id
  where cs.trainer_id = p_trainer_id
    and cs.session_date between p_from and p_to
  group by
    cs.id,
    cs.session_date,
    b.batch_name,
    b.course_name,
    cs.session_number,
    cs.topic_covered,
    cs.status
  order by
    cs.session_date desc,
    cs.session_number desc nulls last;
end;
$$;

grant execute on function public.trainer_class_report(uuid,date,date)
to authenticated;

create or replace function public.lms_attendance_report(
  p_from date,
  p_to date,
  p_batch_id uuid default null
)
returns table (
  session_id uuid,
  class_date date,
  batch_name text,
  course_name text,
  session_number integer,
  student_name text,
  attendance_status text,
  trainer_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.can_view_lms() then
    raise exception 'You do not have permission to view LMS reports.';
  end if;

  return query
  select
    cs.id,
    cs.session_date,
    b.batch_name,
    b.course_name,
    cs.session_number,
    s.student_name,
    sa.attendance_status,
    cs.trainer_name
  from public.class_sessions cs
  join public.batches b
    on b.id = cs.batch_id
  join public.batch_students bs
    on bs.batch_id = b.id
  join public.students s
    on s.id = bs.student_id
  left join public.session_attendance sa
    on sa.session_id = cs.id
   and sa.student_id = s.id
  where cs.session_date between p_from and p_to
    and (p_batch_id is null or b.id = p_batch_id)
  order by
    cs.session_date desc,
    b.batch_name,
    s.student_name;
end;
$$;

grant execute on function public.lms_attendance_report(date,date,uuid)
to authenticated;

create or replace function public.lms_batch_progress_report()
returns table (
  batch_id uuid,
  batch_name text,
  course_name text,
  trainer_name text,
  batch_status text,
  planned_sessions integer,
  total_sessions integer,
  completed_sessions integer,
  student_count integer,
  attendance_rate numeric,
  homework_rate numeric
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.can_view_lms() then
    raise exception 'You do not have permission to view LMS reports.';
  end if;

  return query
  with session_stats as (
    select
      b.id as batch_id,
      count(distinct cs.id)::integer as total_sessions,
      count(distinct cs.id) filter (
        where cs.status = 'Completed'
      )::integer as completed_sessions
    from public.batches b
    left join public.class_sessions cs
      on cs.batch_id = b.id
    group by b.id
  ),
  roster_stats as (
    select
      b.id as batch_id,
      count(distinct bs.student_id)::integer as student_count
    from public.batches b
    left join public.batch_students bs
      on bs.batch_id = b.id
    group by b.id
  ),
  attendance_stats as (
    select
      cs.batch_id,
      round(
        100.0 *
        count(sa.id) filter (
          where sa.attendance_status in ('Present','Late')
        ) /
        nullif(count(sa.id),0),
        1
      ) as attendance_rate
    from public.class_sessions cs
    left join public.session_attendance sa
      on sa.session_id = cs.id
    group by cs.batch_id
  ),
  homework_stats as (
    select
      cs.batch_id,
      round(
        100.0 *
        count(sh.id) filter (
          where sh.homework_completed = true
        ) /
        nullif(count(sh.id),0),
        1
      ) as homework_rate
    from public.class_sessions cs
    left join public.session_homework sh
      on sh.session_id = cs.id
    group by cs.batch_id
  )
  select
    b.id,
    b.batch_name,
    b.course_name,
    b.trainer_name,
    b.status,
    b.planned_sessions,
    coalesce(ss.total_sessions,0),
    coalesce(ss.completed_sessions,0),
    coalesce(rs.student_count,0),
    ats.attendance_rate,
    hs.homework_rate
  from public.batches b
  left join session_stats ss
    on ss.batch_id = b.id
  left join roster_stats rs
    on rs.batch_id = b.id
  left join attendance_stats ats
    on ats.batch_id = b.id
  left join homework_stats hs
    on hs.batch_id = b.id
  order by
    case b.status
      when 'Active' then 1
      when 'Upcoming' then 2
      when 'Paused' then 3
      else 4
    end,
    b.batch_name;
end;
$$;

grant execute on function public.lms_batch_progress_report()
to authenticated;

create or replace function public.student_progress_report(
  p_student_id uuid
)
returns table (
  session_id uuid,
  class_date date,
  batch_name text,
  course_name text,
  session_number integer,
  topic_covered text,
  class_status text,
  attendance_status text,
  homework_completed boolean
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.can_view_student(p_student_id) then
    raise exception 'You do not have permission to view this student.';
  end if;

  return query
  select
    cs.id,
    cs.session_date,
    b.batch_name,
    b.course_name,
    cs.session_number,
    cs.topic_covered,
    cs.status,
    sa.attendance_status,
    sh.homework_completed
  from public.batch_students bs
  join public.batches b
    on b.id = bs.batch_id
  join public.class_sessions cs
    on cs.batch_id = b.id
  left join public.session_attendance sa
    on sa.session_id = cs.id
   and sa.student_id = p_student_id
  left join public.session_homework sh
    on sh.session_id = cs.id
   and sh.student_id = p_student_id
  where bs.student_id = p_student_id
  order by
    cs.session_date desc,
    cs.session_number desc nulls last;
end;
$$;

grant execute on function public.student_progress_report(uuid)
to authenticated;

-- ------------------------------------------------------------
-- 8. TRAINER DIRECTORY VISIBILITY
-- Marketing/Management can view directory; only LMS admins edit.
-- ------------------------------------------------------------
alter table public.trainers enable row level security;

drop policy if exists "Staff can view trainers"
on public.trainers;

drop policy if exists "Admin and Sales can manage trainers"
on public.trainers;

drop policy if exists "Role matrix view trainers"
on public.trainers;

drop policy if exists "Final LMS view trainers"
on public.trainers;

drop policy if exists "Final LMS manage trainers"
on public.trainers;

create policy "Final LMS view trainers"
on public.trainers
for select to authenticated
using (
  public.can_view_lms()
  or id = public.current_trainer_id()
);

create policy "Final LMS manage trainers"
on public.trainers
for all to authenticated
using (public.is_lms_admin())
with check (public.is_lms_admin());

-- ------------------------------------------------------------
-- 9. FINAL VIEW POLICIES FOR LMS TABLES
-- Existing manager/teacher write policies remain in place and use
-- the final helper functions above.
-- ------------------------------------------------------------

-- Students
drop policy if exists "Role matrix view students" on public.students;
drop policy if exists "Final LMS view students" on public.students;

create policy "Final LMS view students"
on public.students
for select to authenticated
using (public.can_view_student(id));

-- Enrollments
drop policy if exists "Role matrix view enrollments"
on public.student_enrollments;
drop policy if exists "Final LMS view enrollments"
on public.student_enrollments;

create policy "Final LMS view enrollments"
on public.student_enrollments
for select to authenticated
using (public.can_view_student(student_id));

-- Batches
drop policy if exists "Role matrix view batches" on public.batches;
drop policy if exists "Final LMS view batches" on public.batches;

create policy "Final LMS view batches"
on public.batches
for select to authenticated
using (public.can_view_batch(id));

-- Batch roster
drop policy if exists "Role matrix view batch students"
on public.batch_students;
drop policy if exists "Final LMS view roster"
on public.batch_students;

create policy "Final LMS view roster"
on public.batch_students
for select to authenticated
using (public.can_view_batch(batch_id));

-- Classes
drop policy if exists "Role matrix view class sessions"
on public.class_sessions;
drop policy if exists "Final LMS view sessions"
on public.class_sessions;

create policy "Final LMS view sessions"
on public.class_sessions
for select to authenticated
using (public.can_view_batch(batch_id));

-- Attendance
drop policy if exists "Role matrix view attendance"
on public.session_attendance;
drop policy if exists "Final LMS view attendance"
on public.session_attendance;

create policy "Final LMS view attendance"
on public.session_attendance
for select to authenticated
using (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_attendance.session_id
      and public.can_view_batch(cs.batch_id)
  )
);

-- Homework
drop policy if exists "Role matrix view homework"
on public.session_homework;
drop policy if exists "Final LMS view homework"
on public.session_homework;

create policy "Final LMS view homework"
on public.session_homework
for select to authenticated
using (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_homework.session_id
      and public.can_view_batch(cs.batch_id)
  )
);

-- Trainer assignment history
drop policy if exists "Role matrix view trainer history"
on public.batch_trainer_assignments;
drop policy if exists "Final LMS view trainer history"
on public.batch_trainer_assignments;

create policy "Final LMS view trainer history"
on public.batch_trainer_assignments
for select to authenticated
using (public.can_view_batch(batch_id));

-- ============================================================
-- END
-- ============================================================
