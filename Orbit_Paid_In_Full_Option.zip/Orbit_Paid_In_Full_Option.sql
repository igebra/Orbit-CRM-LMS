-- ============================================================
-- ORBIT - PAID IN FULL PAYMENT PLAN
-- Safe function update only.
-- No CRM data changed.
-- No payment rows deleted or rewritten.
-- ============================================================

create or replace function public.ensure_payment_plan_for_entry(
  p_batch_id uuid,
  p_student_id uuid,
  p_total_fee_usd numeric,
  p_payment_plan text,
  p_installment_amount_usd numeric,
  p_plan_start_date date
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role text;
  v_id uuid;
  v_installment numeric;
begin
  select role into v_role
  from public.user_profiles
  where id=auth.uid();

  if v_role not in (
    'super_admin',
    'admin',
    'sales',
    'sales_marketing',
    'accounts_finance'
  ) then
    raise exception 'You do not have permission to configure payment plans.';
  end if;

  if not exists (
    select 1
    from public.batch_students
    where batch_id=p_batch_id
      and student_id=p_student_id
  ) then
    raise exception 'This student is not assigned to this batch.';
  end if;

  if p_total_fee_usd is null or p_total_fee_usd <= 0 then
    raise exception 'Total fee must be greater than zero.';
  end if;

  if p_payment_plan not in (
    'After Every 4 Classes',
    'Monthly',
    'Quarterly',
    'Half-yearly',
    'Yearly',
    'Paid in Full',
    'Custom'
  ) then
    raise exception 'Invalid payment plan.';
  end if;

  v_installment := case
    when p_payment_plan='Paid in Full' then p_total_fee_usd
    else p_installment_amount_usd
  end;

  if v_installment is null or v_installment <= 0 then
    raise exception 'Installment amount must be greater than zero.';
  end if;

  insert into public.batch_student_finance(
    batch_id,
    student_id,
    total_fee_usd,
    payment_plan,
    installment_amount_usd,
    plan_start_date,
    created_by,
    updated_by
  )
  values(
    p_batch_id,
    p_student_id,
    p_total_fee_usd,
    p_payment_plan,
    v_installment,
    p_plan_start_date,
    auth.uid(),
    auth.uid()
  )
  on conflict(batch_id,student_id)
  do update set
    total_fee_usd=excluded.total_fee_usd,
    payment_plan=excluded.payment_plan,
    installment_amount_usd=excluded.installment_amount_usd,
    plan_start_date=excluded.plan_start_date,
    updated_by=auth.uid()
  returning id into v_id;

  return v_id;
end;
$$;

grant execute on function public.ensure_payment_plan_for_entry(
  uuid,uuid,numeric,text,numeric,date
) to authenticated;
