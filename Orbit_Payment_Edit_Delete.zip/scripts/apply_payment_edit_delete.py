from pathlib import Path
import re

page_path = Path('app/payments/page.tsx')
css_path = Path('app/payments/payments.module.css')

for p in (page_path, css_path):
    if not p.exists():
        raise SystemExit(f'Missing {p}. Run this from the Orbit repository root.')

page = page_path.read_text(encoding='utf-8')
css = css_path.read_text(encoding='utf-8')

# ------------------------------------------------------------
# 1) Add state for edit/delete transaction flows
# ------------------------------------------------------------
state_anchor = '''  const [paymentOpen, setPaymentOpen] = useState(false);\n  const [savingPayment, setSavingPayment] = useState(false);'''
state_new = '''  const [paymentOpen, setPaymentOpen] = useState(false);\n  const [savingPayment, setSavingPayment] = useState(false);\n  const [editPaymentOpen, setEditPaymentOpen] = useState(false);\n  const [deletePaymentOpen, setDeletePaymentOpen] = useState(false);\n  const [savingCorrection, setSavingCorrection] = useState(false);\n  const [editTransaction, setEditTransaction] = useState<Transaction | null>(null);\n  const [deleteTransaction, setDeleteTransaction] = useState<Transaction | null>(null);\n  const [deleteReason, setDeleteReason] = useState(\"\");\n  const [editForm, setEditForm] = useState({\n    amount_usd: \"\",\n    payment_date: localIso(new Date()),\n    payment_mode: \"Zelle\",\n    reference: \"\",\n  });'''
if 'editPaymentOpen' not in page:
    if state_anchor not in page:
        raise SystemExit('Could not locate payment modal state block.')
    page = page.replace(state_anchor, state_new, 1)

# ------------------------------------------------------------
# 2) Add edit/delete handlers before exportCsv
# ------------------------------------------------------------
anchor = '  function exportCsv() {'
handlers = r'''  function openEditPayment(row: Transaction) {
    setEditTransaction(row);
    setEditForm({
      amount_usd: String(row.amount_usd ?? ""),
      payment_date: row.payment_date,
      payment_mode: row.payment_mode || "Zelle",
      reference: row.reference || "",
    });
    setEditPaymentOpen(true);
  }

  async function saveEditedPayment(event: React.FormEvent) {
    event.preventDefault();
    if (!editTransaction) return;

    const amount = Number(editForm.amount_usd);
    if (!amount || amount <= 0) {
      setMessage("Enter a valid payment amount.");
      return;
    }
    if (!editForm.payment_date) {
      setMessage("Payment Date is required.");
      return;
    }

    setSavingCorrection(true);
    setMessage("");

    const { error } = await supabase.rpc("edit_payment_transaction", {
      p_transaction_id: editTransaction.transaction_id,
      p_amount_usd: amount,
      p_payment_date: editForm.payment_date,
      p_payment_mode: editForm.payment_mode,
      p_reference: editForm.reference.trim() || null,
    });

    setSavingCorrection(false);
    if (error) {
      setMessage(error.message);
      return;
    }

    setEditPaymentOpen(false);
    setEditTransaction(null);
    setMessage("Payment updated successfully. The previous value is retained in the correction log.");
    await loadReports(from, to);
  }

  function openDeletePayment(row: Transaction) {
    setDeleteTransaction(row);
    setDeleteReason("");
    setDeletePaymentOpen(true);
  }

  async function confirmDeletePayment() {
    if (!deleteTransaction) return;
    if (deleteReason.trim().length < 3) {
      setMessage("Enter a short reason for deleting this payment.");
      return;
    }

    setSavingCorrection(true);
    setMessage("");

    const { error } = await supabase.rpc("delete_payment_transaction", {
      p_transaction_id: deleteTransaction.transaction_id,
      p_reason: deleteReason.trim(),
    });

    setSavingCorrection(false);
    if (error) {
      setMessage(error.message);
      return;
    }

    setDeletePaymentOpen(false);
    setDeleteTransaction(null);
    setDeleteReason("");
    setMessage("Payment removed from reports. An audit copy has been retained.");
    await loadReports(from, to);
  }

'''
if 'function openEditPayment(' not in page:
    if anchor not in page:
        raise SystemExit('Could not locate exportCsv() anchor.')
    page = page.replace(anchor, handlers + anchor, 1)

# ------------------------------------------------------------
# 3) Add Actions column and buttons in Transactions table
# ------------------------------------------------------------
header_old = '''                  <th>Mode</th>\n                  <th>Reference</th>'''
header_new = '''                  <th>Mode</th>\n                  <th>Reference</th>\n                  {canManageFinance && <th>Actions</th>}'''
if header_old in page and 'canManageFinance && <th>Actions</th>' not in page:
    page = page.replace(header_old, header_new, 1)

empty_old = '''                    <td colSpan={8} className={styles.empty}>'''
empty_new = '''                    <td colSpan={canManageFinance ? 9 : 8} className={styles.empty}>'''
if empty_old in page:
    page = page.replace(empty_old, empty_new, 1)

row_old = '''                      <td>{row.payment_mode}</td>\n                      <td>{row.reference || "—"}</td>'''
row_new = '''                      <td>{row.payment_mode}</td>\n                      <td>{row.reference || "—"}</td>\n                      {canManageFinance && (\n                        <td>\n                          <div className={styles.transactionActions}>\n                            <button\n                              type="button"\n                              className={styles.editAction}\n                              onClick={() => openEditPayment(row)}\n                            >\n                              Edit\n                            </button>\n                            <button\n                              type="button"\n                              className={styles.deleteAction}\n                              onClick={() => openDeletePayment(row)}\n                            >\n                              Delete\n                            </button>\n                          </div>\n                        </td>\n                      )}'''
if row_old in page and 'openEditPayment(row)' not in page:
    page = page.replace(row_old, row_new, 1)

if 'openEditPayment(row)' not in page:
    raise SystemExit('Could not patch transaction action buttons.')

# ------------------------------------------------------------
# 4) Add Edit + Delete modals before Add Payment modal
# ------------------------------------------------------------
modal_anchor = '''      {paymentOpen && ('''
modals = r'''      {editPaymentOpen && editTransaction && (
        <div className={styles.backdrop}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <div>
                <h2>Edit Payment</h2>
                <p>{editTransaction.student_name} · {editTransaction.batch_name}</p>
              </div>
              <button type="button" className={styles.close} onClick={() => setEditPaymentOpen(false)}>×</button>
            </div>

            <form onSubmit={saveEditedPayment}>
              <div className={styles.correctionSummary}>
                <strong>Original transaction will be preserved in the audit log.</strong>
                <span>Edit only the payment details that were entered incorrectly.</span>
              </div>

              <div className={styles.formGrid}>
                <label>
                  <span>Amount USD *</span>
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={editForm.amount_usd}
                    onChange={(event) => setEditForm({...editForm, amount_usd:event.target.value})}
                  />
                </label>

                <label>
                  <span>Payment Date *</span>
                  <input
                    type="date"
                    value={editForm.payment_date}
                    onChange={(event) => setEditForm({...editForm, payment_date:event.target.value})}
                  />
                </label>

                <label>
                  <span>Payment Mode *</span>
                  <select
                    value={editForm.payment_mode}
                    onChange={(event) => setEditForm({...editForm, payment_mode:event.target.value})}
                  >
                    {PAYMENT_MODES.map((mode) => <option key={mode}>{mode}</option>)}
                  </select>
                </label>

                <label>
                  <span>Reference / Transaction ID</span>
                  <input
                    value={editForm.reference}
                    onChange={(event) => setEditForm({...editForm, reference:event.target.value})}
                    placeholder="Optional"
                  />
                </label>
              </div>

              <div className={styles.modalFooter}>
                <button type="button" className={styles.secondary} onClick={() => setEditPaymentOpen(false)}>Cancel</button>
                <button type="submit" className={styles.primary} disabled={savingCorrection}>
                  {savingCorrection ? "Saving..." : "Save Correction"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deletePaymentOpen && deleteTransaction && (
        <div className={styles.backdrop}>
          <div className={`${styles.modal} ${styles.deleteModal}`}>
            <div className={styles.modalHeader}>
              <div>
                <h2>Delete Payment</h2>
                <p>{deleteTransaction.student_name} · {deleteTransaction.batch_name}</p>
              </div>
              <button type="button" className={styles.close} onClick={() => setDeletePaymentOpen(false)}>×</button>
            </div>

            <div className={styles.deleteBody}>
              <div className={styles.deleteWarning}>
                <strong>{money(deleteTransaction.amount_usd)} will be removed from payment reports.</strong>
                <span>The original transaction is retained in Orbit's correction log for accountability.</span>
              </div>

              <label>
                <span>Reason for deletion *</span>
                <textarea
                  value={deleteReason}
                  onChange={(event) => setDeleteReason(event.target.value)}
                  placeholder="Example: Duplicate payment / wrong student / incorrect entry"
                  rows={3}
                />
              </label>
            </div>

            <div className={styles.modalFooter}>
              <button type="button" className={styles.secondary} onClick={() => setDeletePaymentOpen(false)}>Cancel</button>
              <button type="button" className={styles.deleteConfirm} disabled={savingCorrection} onClick={confirmDeletePayment}>
                {savingCorrection ? "Deleting..." : "Delete Payment"}
              </button>
            </div>
          </div>
        </div>
      )}

'''
if 'editPaymentOpen && editTransaction' not in page:
    if modal_anchor not in page:
        raise SystemExit('Could not locate Add Payment modal.')
    page = page.replace(modal_anchor, modals + modal_anchor, 1)

page_path.write_text(page, encoding='utf-8')

# ------------------------------------------------------------
# 5) Styling
# ------------------------------------------------------------
marker = '/* ORBIT PAYMENT EDIT DELETE */'
if marker not in css:
    css += r'''

/* ORBIT PAYMENT EDIT DELETE */
.transactionActions{display:flex;gap:6px;flex-wrap:wrap}
.editAction,.deleteAction{height:30px;padding:0 9px;border-radius:7px;font-size:9.5px;font-weight:850;cursor:pointer;background:#fff}
.editAction{border:1px solid #b9d4cf;color:#0f5e61}
.editAction:hover{background:#edf7f5;border-color:#74AFAD}
.deleteAction{border:1px solid #e7c3c1;color:#a0443f}
.deleteAction:hover{background:#fff1ef;border-color:#d99490}
.correctionSummary{margin:16px 20px 0;padding:11px 12px;border:1px solid #cfe0dd;border-radius:10px;background:#f5faf9}
.correctionSummary strong,.correctionSummary span{display:block}
.correctionSummary strong{font-size:10.5px;color:#174f50}
.correctionSummary span{margin-top:3px;font-size:9.5px;color:#70817f}
.deleteModal{width:min(560px,95vw)}
.deleteBody{padding:18px 20px}
.deleteWarning{padding:12px;border:1px solid #efc3bf;border-radius:10px;background:#fff4f2;margin-bottom:14px}
.deleteWarning strong,.deleteWarning span{display:block}
.deleteWarning strong{font-size:11px;color:#9a3f39}
.deleteWarning span{margin-top:4px;font-size:9.5px;color:#806865;line-height:1.4}
.deleteBody label span{display:block;font-size:10px;font-weight:800;margin-bottom:6px}
.deleteBody textarea{width:100%;resize:vertical;border:1px solid #d8deda;border-radius:9px;padding:9px 10px;font:inherit;color:#173637;background:#fff}
.deleteConfirm{border:1px solid #a94c46;background:#b84f48;color:#fff;border-radius:9px;padding:10px 13px;font-weight:850;cursor:pointer}
.deleteConfirm:disabled{opacity:.55;cursor:not-allowed}
'''

css_path.write_text(css, encoding='utf-8')

print('Payment edit/delete patch applied.')
print('CRM leads are untouched.')
