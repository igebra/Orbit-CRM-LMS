-- ============================================================
-- ORBIT PAYMENT EDIT / DELETE WITH CORRECTION LOG
-- ============================================================
-- DATABASE CHANGE - ADDITIVE / SAFE
-- CRM Leads are NOT touched.
-- Existing payment transactions are NOT modified by this migration.
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.payment_transaction_corrections(
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null,
  action text not null check(action in ('EDIT','DELETE')),
  previous_data jsonb not null,
  new_data jsonb null,
  reason text null,
  changed_by uuid null,
  changed_by_email text null,
  changed_at timestamptz not null default now()
);

create index if not exists payment_transaction_corrections_txn_idx
  on public.payment_transaction_corrections(transaction_id,changed_at desc);

alter table public.payment_transaction_corrections enable row level security;

drop policy if exists payment_transaction_corrections_select on public.payment_transaction_corrections;
create policy payment_transaction_corrections_select
on public.payment_transaction_corrections
for select
to authenticated
using(public.can_view_finance());

grant select on public.payment_transaction_corrections to authenticated;

-- Allowed managers:
-- Super Admin / Admin / Sales Admin / Finance Admin
create or replace function public.orbit_can_manage_payments()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.user_profiles
    where id=auth.uid()
      and role in ('super_admin','admin','sales','sales_marketing','accounts_finance')
  );
$$;

grant execute on function public.orbit_can_manage_payments() to authenticated;

create or replace function public.edit_payment_transaction(
  p_transaction_id uuid,
  p_amount_usd numeric,
  p_payment_date date,
  p_payment_mode text,
  p_reference text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.payment_transactions%rowtype;
  v_new public.payment_transactions%rowtype;
  v_email text;
begin
  if not public.orbit_can_manage_payments() then
    raise exception 'You do not have permission to edit payments.';
  end if;

  if p_amount_usd is null or p_amount_usd <= 0 then
    raise exception 'Payment amount must be greater than zero.';
  end if;

  if p_payment_date is null then
    raise exception 'Payment date is required.';
  end if;

  select * into v_old
  from public.payment_transactions
  where id=p_transaction_id;

  if not found then
    raise exception 'Payment transaction not found.';
  end if;

  update public.payment_transactions
  set
    amount_usd=p_amount_usd,
    payment_date=p_payment_date,
    payment_mode=p_payment_mode,
    reference=nullif(trim(coalesce(p_reference,'')),'')
  where id=p_transaction_id
  returning * into v_new;

  begin
    v_email:=auth.jwt()->>'email';
  exception when others then
    v_email:=null;
  end;

  insert into public.payment_transaction_corrections(
    transaction_id,action,previous_data,new_data,reason,changed_by,changed_by_email
  )
  values(
    p_transaction_id,
    'EDIT',
    to_jsonb(v_old),
    to_jsonb(v_new),
    'Payment corrected by authorised Orbit user',
    auth.uid(),
    v_email
  );
end;
$$;

grant execute on function public.edit_payment_transaction(uuid,numeric,date,text,text)
to authenticated;

create or replace function public.delete_payment_transaction(
  p_transaction_id uuid,
  p_reason text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.payment_transactions%rowtype;
  v_email text;
begin
  if not public.orbit_can_manage_payments() then
    raise exception 'You do not have permission to delete payments.';
  end if;

  if length(trim(coalesce(p_reason,''))) < 3 then
    raise exception 'A deletion reason is required.';
  end if;

  select * into v_old
  from public.payment_transactions
  where id=p_transaction_id;

  if not found then
    raise exception 'Payment transaction not found.';
  end if;

  begin
    v_email:=auth.jwt()->>'email';
  exception when others then
    v_email:=null;
  end;

  insert into public.payment_transaction_corrections(
    transaction_id,action,previous_data,new_data,reason,changed_by,changed_by_email
  )
  values(
    p_transaction_id,
    'DELETE',
    to_jsonb(v_old),
    null,
    trim(p_reason),
    auth.uid(),
    v_email
  );

  delete from public.payment_transactions
  where id=p_transaction_id;
end;
$$;

grant execute on function public.delete_payment_transaction(uuid,text)
to authenticated;

-- ============================================================
-- END
-- ============================================================
