-- ============================================================
-- ORBIT - SIMPLE PAYMENT DELETE + SUPER ADMIN DELETE AUDIT
-- ============================================================
-- DATABASE CHANGE - ADDITIVE / SAFE
--
-- CRM leads are NOT touched.
-- Existing payments are NOT changed by this migration.
-- A payment changes only when an authorized user explicitly deletes it.
-- Deleted transaction details are preserved in an audit table.
-- ============================================================

create table if not exists public.payment_transaction_corrections (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null,
  finance_id uuid,
  action text not null check (action in ('EDIT','DELETE')),
  old_amount_usd numeric,
  old_payment_date date,
  old_payment_mode text,
  old_reference text,
  new_amount_usd numeric,
  new_payment_date date,
  new_payment_mode text,
  new_reference text,
  reason text,
  changed_by uuid,
  changed_at timestamptz not null default now()
);

alter table public.payment_transaction_corrections enable row level security;

revoke all on table public.payment_transaction_corrections from anon;
revoke all on table public.payment_transaction_corrections from authenticated;

create or replace function public.delete_payment_transaction(
  p_transaction_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role text;
  v_old public.payment_transactions%rowtype;
begin
  select role into v_role
  from public.user_profiles
  where id = auth.uid();

  if v_role not in (
    'super_admin',
    'admin',
    'sales',
    'sales_marketing',
    'accounts_finance'
  ) then
    raise exception 'You do not have permission to delete payments.';
  end if;

  select *
  into v_old
  from public.payment_transactions
  where id = p_transaction_id
  for update;

  if not found then
    raise exception 'Payment transaction not found.';
  end if;

  insert into public.payment_transaction_corrections (
    transaction_id,
    finance_id,
    action,
    old_amount_usd,
    old_payment_date,
    old_payment_mode,
    old_reference,
    changed_by
  )
  values (
    v_old.id,
    v_old.finance_id,
    'DELETE',
    v_old.amount_usd,
    v_old.payment_date,
    v_old.payment_mode,
    v_old.reference,
    auth.uid()
  );

  delete from public.payment_transactions
  where id = p_transaction_id;
end;
$$;

grant execute on function public.delete_payment_transaction(uuid)
to authenticated;

create or replace function public.deleted_payment_report()
returns table (
  correction_id uuid,
  transaction_id uuid,
  student_name text,
  batch_name text,
  course_name text,
  payment_plan text,
  amount_usd numeric,
  payment_date date,
  payment_mode text,
  reference text,
  deleted_by uuid,
  deleted_by_email text,
  deleted_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public, auth
as $$
declare
  v_role text;
begin
  select role into v_role
  from public.user_profiles
  where id = auth.uid();

  if v_role <> 'super_admin' then
    raise exception 'Only Super Admin can view deleted payments.';
  end if;

  return query
  select
    c.id as correction_id,
    c.transaction_id,
    coalesce(s.student_name,'Unknown Student')::text as student_name,
    coalesce(b.batch_name,'Unknown Batch')::text as batch_name,
    coalesce(b.course_name,'Unknown Course')::text as course_name,
    coalesce(f.payment_plan,'Unknown')::text as payment_plan,
    coalesce(c.old_amount_usd,0)::numeric as amount_usd,
    c.old_payment_date as payment_date,
    coalesce(c.old_payment_mode,'Unknown')::text as payment_mode,
    c.old_reference as reference,
    c.changed_by as deleted_by,
    u.email::text as deleted_by_email,
    c.changed_at as deleted_at
  from public.payment_transaction_corrections c
  left join public.batch_student_finance f
    on f.id = c.finance_id
  left join public.students s
    on s.id = f.student_id
  left join public.batches b
    on b.id = f.batch_id
  left join auth.users u
    on u.id = c.changed_by
  where c.action = 'DELETE'
  order by c.changed_at desc;
end;
$$;

grant execute on function public.deleted_payment_report()
to authenticated;

-- ============================================================
-- END
-- ============================================================
