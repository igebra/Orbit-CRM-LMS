-- ============================================================
-- ORBIT — LMS CONTENT LIBRARY + CURRICULUM
-- Master course material, curriculum sessions, version history,
-- private storage and automatic batch-session inheritance.
-- ============================================================

create extension if not exists pgcrypto;

create or replace function public.can_view_lms_library()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing',
      'marketing','viewer_management','trainer'
    ),
    false
  );
$$;

create or replace function public.can_manage_lms_library()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing','trainer'
    ),
    false
  );
$$;

grant execute on function public.can_view_lms_library() to authenticated;
grant execute on function public.can_manage_lms_library() to authenticated;

create table if not exists public.lms_curriculum_sessions (
  id uuid primary key default gen_random_uuid(),
  course_name text not null,
  session_number integer not null check (session_number > 0),
  topic text,
  learning_objectives text,
  required_resource_types text[] not null default array[
    'PPT / Deck','Worksheet','Homework'
  ]::text[],
  status text not null default 'Draft'
    check (status in ('Draft','Ready','Archived')),
  created_by uuid references auth.users(id) on delete set null,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(course_name, session_number)
);

create index if not exists lms_curriculum_course_idx
  on public.lms_curriculum_sessions(course_name, session_number);

create table if not exists public.lms_resources (
  id uuid primary key default gen_random_uuid(),
  curriculum_session_id uuid not null
    references public.lms_curriculum_sessions(id) on delete cascade,
  resource_type text not null
    check (resource_type in (
      'PPT / Deck','Worksheet','Homework','Assessment',
      'Reference Material','Trainer Guide','Other'
    )),
  title text not null,
  description text,
  is_archived boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists lms_resources_session_idx
  on public.lms_resources(curriculum_session_id, resource_type);

create table if not exists public.lms_resource_versions (
  id uuid primary key default gen_random_uuid(),
  resource_id uuid not null
    references public.lms_resources(id) on delete cascade,
  version_number integer not null check (version_number > 0),
  file_name text not null,
  storage_path text not null unique,
  mime_type text,
  size_bytes bigint
    check (size_bytes is null or size_bytes between 0 and 26214400),
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(resource_id, version_number)
);

create index if not exists lms_resource_versions_resource_idx
  on public.lms_resource_versions(resource_id, version_number desc);

create or replace function public.ensure_lms_curriculum_session(
  p_course_name text,
  p_session_number integer
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  if not public.can_manage_lms_library() then
    raise exception 'You do not have permission to manage LMS content.';
  end if;

  if nullif(trim(p_course_name),'') is null then
    raise exception 'Course name is required.';
  end if;

  if p_session_number is null or p_session_number < 1 then
    raise exception 'Session number must be 1 or greater.';
  end if;

  insert into public.lms_curriculum_sessions (
    course_name, session_number, created_by, updated_by
  )
  values (
    trim(p_course_name), p_session_number, auth.uid(), auth.uid()
  )
  on conflict (course_name, session_number)
  do update set updated_at = public.lms_curriculum_sessions.updated_at
  returning id into v_id;

  return v_id;
end;
$$;

grant execute on function public.ensure_lms_curriculum_session(text,integer)
to authenticated;

create or replace function public.generate_lms_curriculum(
  p_course_name text,
  p_session_count integer,
  p_required_types text[] default array[
    'PPT / Deck','Worksheet','Homework'
  ]::text[]
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_i integer;
  v_inserted integer := 0;
begin
  if not public.can_manage_lms_library() then
    raise exception 'You do not have permission to manage LMS curriculum.';
  end if;

  if nullif(trim(p_course_name),'') is null then
    raise exception 'Course name is required.';
  end if;

  if p_session_count is null or p_session_count < 1 or p_session_count > 200 then
    raise exception 'Session count must be between 1 and 200.';
  end if;

  for v_i in 1..p_session_count loop
    insert into public.lms_curriculum_sessions (
      course_name, session_number, required_resource_types,
      created_by, updated_by
    )
    values (
      trim(p_course_name), v_i,
      coalesce(p_required_types, array[]::text[]),
      auth.uid(), auth.uid()
    )
    on conflict (course_name, session_number) do nothing;

    if found then
      v_inserted := v_inserted + 1;
    end if;
  end loop;

  return v_inserted;
end;
$$;

grant execute on function public.generate_lms_curriculum(text,integer,text[])
to authenticated;

alter table public.lms_curriculum_sessions enable row level security;
alter table public.lms_resources enable row level security;
alter table public.lms_resource_versions enable row level security;

drop policy if exists "LMS curriculum view" on public.lms_curriculum_sessions;
create policy "LMS curriculum view"
on public.lms_curriculum_sessions
for select to authenticated
using (public.can_view_lms_library());

drop policy if exists "LMS curriculum manage" on public.lms_curriculum_sessions;
create policy "LMS curriculum manage"
on public.lms_curriculum_sessions
for all to authenticated
using (public.can_manage_lms_library())
with check (public.can_manage_lms_library());

drop policy if exists "LMS resources view" on public.lms_resources;
create policy "LMS resources view"
on public.lms_resources
for select to authenticated
using (public.can_view_lms_library());

drop policy if exists "LMS resources manage" on public.lms_resources;
create policy "LMS resources manage"
on public.lms_resources
for all to authenticated
using (public.can_manage_lms_library())
with check (public.can_manage_lms_library());

drop policy if exists "LMS versions view" on public.lms_resource_versions;
create policy "LMS versions view"
on public.lms_resource_versions
for select to authenticated
using (public.can_view_lms_library());

drop policy if exists "LMS versions manage" on public.lms_resource_versions;
create policy "LMS versions manage"
on public.lms_resource_versions
for all to authenticated
using (public.can_manage_lms_library())
with check (public.can_manage_lms_library());

insert into storage.buckets (
  id, name, public, file_size_limit, allowed_mime_types
)
values (
  'lms-library','lms-library',false,26214400,null
)
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit;

create or replace function public.can_access_lms_library_path(
  p_name text,
  p_manage boolean default false
)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_resource_id uuid;
begin
  begin
    v_resource_id := split_part(p_name, '/', 1)::uuid;
  exception
    when others then
      return false;
  end;

  if not exists (
    select 1 from public.lms_resources r where r.id = v_resource_id
  ) then
    return false;
  end if;

  if p_manage then
    return public.can_manage_lms_library();
  end if;

  return public.can_view_lms_library();
end;
$$;

grant execute on function public.can_access_lms_library_path(text,boolean)
to authenticated;

drop policy if exists "LMS library storage read" on storage.objects;
create policy "LMS library storage read"
on storage.objects
for select to authenticated
using (
  bucket_id = 'lms-library'
  and public.can_access_lms_library_path(name, false)
);

drop policy if exists "LMS library storage upload" on storage.objects;
create policy "LMS library storage upload"
on storage.objects
for insert to authenticated
with check (
  bucket_id = 'lms-library'
  and public.can_access_lms_library_path(name, true)
);

drop policy if exists "LMS library storage update" on storage.objects;
create policy "LMS library storage update"
on storage.objects
for update to authenticated
using (
  bucket_id = 'lms-library'
  and public.can_access_lms_library_path(name, true)
)
with check (
  bucket_id = 'lms-library'
  and public.can_access_lms_library_path(name, true)
);

drop policy if exists "LMS library storage delete" on storage.objects;
create policy "LMS library storage delete"
on storage.objects
for delete to authenticated
using (
  bucket_id = 'lms-library'
  and public.can_access_lms_library_path(name, true)
);

-- ============================================================
-- END
-- ============================================================
