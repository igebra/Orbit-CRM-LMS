from pathlib import Path

page_path = Path("app/payments/page.tsx")
css_path = Path("app/payments/payments.module.css")

for path in (page_path, css_path):
    if not path.exists():
        raise SystemExit(f"Could not find {path}. Run this from the Orbit repository root.")

page = page_path.read_text(encoding="utf-8")
css = css_path.read_text(encoding="utf-8")

components = r'''
function AddPaymentIcon3D() {
  return (
    <span className={styles.headerActionIconShell} aria-hidden="true">
      <svg viewBox="0 0 56 56" className={styles.headerActionIconSvg}>
        <defs>
          <linearGradient id="payCoinOrange" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#F6B56D" />
            <stop offset="100%" stopColor="#D9853B" />
          </linearGradient>
          <linearGradient id="payCoinTeal" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#8BC5C0" />
            <stop offset="100%" stopColor="#558C89" />
          </linearGradient>
        </defs>
        <ellipse cx="27" cy="36" rx="15" ry="8" fill="#E9C7A8" opacity=".55" />
        <circle cx="27" cy="27" r="15" fill="url(#payCoinOrange)" />
        <circle cx="27" cy="27" r="11" fill="#FFF9F3" opacity=".96" />
        <path d="M27 20v14M20 27h14" stroke="url(#payCoinTeal)" strokeWidth="3.2" strokeLinecap="round" />
        <path d="M43 10l1.4 3.4L48 15l-3.6 1.5L43 20l-1.4-3.5L38 15l3.6-1.6L43 10z" fill="#F5B041" />
      </svg>
    </span>
  );
}

function ExportCsvIcon3D() {
  return (
    <span className={styles.headerActionIconShell} aria-hidden="true">
      <svg viewBox="0 0 56 56" className={styles.headerActionIconSvg}>
        <defs>
          <linearGradient id="csvSheetFace" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#F8FFFF" />
            <stop offset="100%" stopColor="#DDEFEA" />
          </linearGradient>
          <linearGradient id="csvTeal" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#7AB7B2" />
            <stop offset="100%" stopColor="#3E7F7C" />
          </linearGradient>
        </defs>
        <path d="M15 8h20l9 9v29H15z" fill="url(#csvSheetFace)" />
        <path d="M35 8v10h9" fill="#BFDCD8" />
        <path d="M21 24h17M21 30h17M21 36h11" stroke="url(#csvTeal)" strokeWidth="2.6" strokeLinecap="round" />
        <path d="M40 34v9M36 39l4 4 4-4" fill="none" stroke="#D9853B" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  );
}

'''

if "function AddPaymentIcon3D()" not in page:
    anchor = "export default function PaymentsPage()"
    if anchor not in page:
        raise SystemExit("Could not locate PaymentsPage export.")
    page = page.replace(anchor, components + anchor, 1)

old_add = '''            {canManageFinance && (
              <button className={styles.primary} onClick={openManualPayment}>
                + Add Payment
              </button>
            )}'''

new_add = '''            {canManageFinance && (
              <button
                type="button"
                className={`${styles.headerActionCard} ${styles.headerActionCardOrange}`}
                onClick={openManualPayment}
                title="Add Payment"
              >
                <AddPaymentIcon3D />
                <span>Add Payment</span>
              </button>
            )}'''

if old_add in page:
    page = page.replace(old_add, new_add, 1)

old_export = '''            <button
              className={styles.secondary}
              onClick={exportCsv}
              disabled={filteredTransactions.length === 0}
            >
              Export CSV
            </button>'''

new_export = '''            <button
              type="button"
              className={`${styles.headerActionCard} ${styles.headerActionCardTeal}`}
              onClick={exportCsv}
              disabled={filteredTransactions.length === 0}
              title="Export CSV"
            >
              <ExportCsvIcon3D />
              <span>Export CSV</span>
            </button>'''

if old_export in page:
    page = page.replace(old_export, new_export, 1)

if "className={`${styles.headerActionCard} ${styles.headerActionCardOrange}`}" not in page:
    raise SystemExit("Could not patch Add Payment button.")
if "className={`${styles.headerActionCard} ${styles.headerActionCardTeal}`}" not in page:
    raise SystemExit("Could not patch Export CSV button.")

marker = "/* ORBIT PAYMENTS 3D HEADER ACTIONS */"
if marker not in css:
    css += r'''

/* ORBIT PAYMENTS 3D HEADER ACTIONS */
.headerActions{
  display:flex;
  gap:10px;
  align-items:flex-start;
  flex-wrap:wrap;
}

.headerActionCard{
  width:92px;
  min-width:92px;
  height:82px;
  padding:8px 7px 7px;
  border-radius:14px;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:4px;
  cursor:pointer;
  font-weight:850;
  transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease;
  box-shadow:0 8px 18px rgba(31,78,75,.08),inset 0 1px 0 rgba(255,255,255,.95);
}

.headerActionCard:hover:not(:disabled){
  transform:translateY(-2px);
}

.headerActionCard:active:not(:disabled){
  transform:translateY(0);
}

.headerActionCard:disabled{
  opacity:.42;
  cursor:not-allowed;
  filter:saturate(.7);
}

.headerActionCardOrange{
  border:1px solid #efbf8e;
  background:linear-gradient(145deg,#ffffff 4%,#fff4e8 100%);
  color:#9b5b27;
}

.headerActionCardOrange:hover:not(:disabled){
  border-color:#D9853B;
  box-shadow:0 11px 22px rgba(217,133,59,.15),inset 0 1px 0 rgba(255,255,255,.95);
}

.headerActionCardTeal{
  border:1px solid #bfd8d4;
  background:linear-gradient(145deg,#ffffff 4%,#eef8f6 100%);
  color:#376f6d;
}

.headerActionCardTeal:hover:not(:disabled){
  border-color:#74AFAD;
  box-shadow:0 11px 22px rgba(85,140,137,.14),inset 0 1px 0 rgba(255,255,255,.95);
}

.headerActionCard>span:last-child{
  font-size:10px;
  line-height:1.05;
  white-space:nowrap;
}

.headerActionIconShell{
  width:42px;
  height:42px;
  display:grid;
  place-items:center;
  border:1px solid rgba(180,204,200,.65);
  border-radius:11px;
  background:linear-gradient(145deg,#ffffff,#f7fbfa);
  box-shadow:0 5px 11px rgba(30,73,70,.09),inset 0 1px 0 rgba(255,255,255,.95);
}

.headerActionIconSvg{
  width:36px;
  height:36px;
  filter:drop-shadow(0 3px 3px rgba(72,91,89,.12));
}

@media(max-width:800px){
  .headerActions{
    width:100%;
  }

  .headerActionCard{
    flex:1;
    min-width:120px;
    height:64px;
    flex-direction:row;
    justify-content:center;
  }

  .headerActionCard>span:last-child{
    font-size:11px;
  }
}
'''

page_path.write_text(page, encoding="utf-8")
css_path.write_text(css, encoding="utf-8")

print("Payments UI patch applied.")
print("UI only - no database changes.")
