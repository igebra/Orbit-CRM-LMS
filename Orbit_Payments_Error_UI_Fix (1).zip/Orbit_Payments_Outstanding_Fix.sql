-- ============================================================
-- ORBIT PAYMENTS OUTSTANDING REPORT FIX
-- ============================================================
-- Root cause:
-- payment_outstanding_report() references ps.finance_id.
-- batch_student_payment_summary exposes the finance record primary key as ps.id.
-- Fix: ps.id AS finance_id.
--
-- No table changes. No data updates/deletes.
-- ============================================================

create or replace function public.payment_outstanding_report()
returns table (
  finance_id uuid,
  student_id uuid,
  student_name text,
  batch_id uuid,
  batch_name text,
  course_name text,
  payment_plan text,
  total_fee_usd numeric,
  total_paid_usd numeric,
  pending_usd numeric,
  next_due_date date,
  next_due_label text,
  payment_status text
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.can_view_finance() then
    raise exception 'You do not have permission to view payment reports.';
  end if;

  return query
  select
    ps.id as finance_id,
    ps.student_id,
    ps.student_name,
    ps.batch_id,
    b.batch_name,
    b.course_name,
    ps.payment_plan,
    ps.total_fee_usd,
    ps.total_paid_usd,
    ps.pending_usd,
    ps.next_due_date,
    ps.next_due_label,
    ps.payment_status
  from public.batch_student_payment_summary ps
  join public.batches b
    on b.id = ps.batch_id
  where ps.total_fee_usd > 0
  order by
    case
      when ps.payment_status = 'Overdue' then 1
      when ps.payment_status = 'Due Soon' then 2
      when ps.payment_status = 'Partial' then 3
      when ps.payment_status = 'Pending' then 4
      when ps.payment_status = 'Paid' then 5
      else 6
    end,
    ps.next_due_date nulls last,
    ps.student_name;
end;
$$;

grant execute on function public.payment_outstanding_report()
to authenticated;

-- ============================================================
-- END
-- ============================================================
