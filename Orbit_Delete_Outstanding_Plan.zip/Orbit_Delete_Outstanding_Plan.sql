-- ============================================================
-- ORBIT - DELETE CURRENT OUTSTANDING / PAYMENT PLAN
-- ============================================================
-- Why Current Outstanding remains after deleting a transaction:
-- payment_transactions = money received
-- batch_student_finance = fee/payment plan owed by the student
--
-- Deleting a transaction does NOT delete the payment plan.
-- This adds a separate, safe delete-payment-plan action.
--
-- DATA SAFE:
-- - CRM leads are NOT touched.
-- - Student remains in the batch.
-- - Existing payment transactions are NOT deleted here.
-- - A plan can only be deleted when it has ZERO live payment transactions.
-- - Deleted plan details are snapshotted into an audit table first.
-- ============================================================

create table if not exists public.deleted_payment_plan_log (
  id uuid primary key default gen_random_uuid(),
  original_finance_id uuid not null,
  student_id uuid,
  student_name text,
  batch_id uuid,
  batch_name text,
  course_name text,
  total_fee_usd numeric,
  payment_plan text,
  installment_amount_usd numeric,
  plan_start_date date,
  deleted_by uuid not null,
  deleted_by_email text,
  deleted_at timestamptz not null default now()
);

alter table public.deleted_payment_plan_log enable row level security;

revoke all on table public.deleted_payment_plan_log from anon;
revoke all on table public.deleted_payment_plan_log from authenticated;

create or replace function public.delete_student_payment_plan(
  p_finance_id uuid
)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_role text;
  v_transaction_count integer;
  v_logged integer;
begin
  select role
    into v_role
  from public.user_profiles
  where id = auth.uid();

  if v_role not in (
    'super_admin',
    'admin',
    'sales',
    'sales_marketing',
    'accounts_finance'
  ) then
    raise exception 'You do not have permission to delete payment plans.';
  end if;

  select count(*)
    into v_transaction_count
  from public.payment_transactions
  where finance_id = p_finance_id;

  if v_transaction_count > 0 then
    raise exception 'This payment plan still has payment transactions. Delete those transactions first.';
  end if;

  insert into public.deleted_payment_plan_log (
    original_finance_id,
    student_id,
    student_name,
    batch_id,
    batch_name,
    course_name,
    total_fee_usd,
    payment_plan,
    installment_amount_usd,
    plan_start_date,
    deleted_by,
    deleted_by_email,
    deleted_at
  )
  select
    f.id,
    f.student_id,
    s.student_name,
    f.batch_id,
    b.batch_name,
    b.course_name,
    f.total_fee_usd,
    f.payment_plan,
    f.installment_amount_usd,
    f.plan_start_date,
    auth.uid(),
    au.email,
    now()
  from public.batch_student_finance f
  left join public.students s
    on s.id = f.student_id
  left join public.batches b
    on b.id = f.batch_id
  left join auth.users au
    on au.id = auth.uid()
  where f.id = p_finance_id;

  get diagnostics v_logged = row_count;

  if v_logged = 0 then
    raise exception 'Payment plan not found.';
  end if;

  delete from public.batch_student_finance
  where id = p_finance_id;
end;
$$;

grant execute on function public.delete_student_payment_plan(uuid)
to authenticated;

notify pgrst, 'reload schema';

-- ============================================================
-- END
-- ============================================================
