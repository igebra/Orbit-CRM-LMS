-- ============================================================
-- ORBIT — CRM FINAL COMPLETE SYNC
-- Safe to run after the previous Orbit CRM / Access SQL updates.
-- ============================================================

create or replace function public.can_view_crm()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing',
      'marketing','viewer_management'
    ),
    false
  );
$$;

create or replace function public.can_manage_crm()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing','marketing'
    ),
    false
  );
$$;

create or replace function public.can_convert_lead()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing'
    ),
    false
  );
$$;

-- Marketing can edit Leads, but Demo operations are view-only.
create or replace function public.can_manage_demos()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_orbit_role() in (
      'super_admin','admin','sales','sales_marketing'
    ),
    false
  );
$$;

grant execute on function public.can_manage_demos()
to authenticated;

alter table public.demo_sessions enable row level security;

drop policy if exists "CRM users can view demo sessions"
on public.demo_sessions;
create policy "CRM users can view demo sessions"
on public.demo_sessions for select to authenticated
using (public.can_view_crm());

drop policy if exists "CRM managers can create demo sessions"
on public.demo_sessions;
create policy "CRM managers can create demo sessions"
on public.demo_sessions for insert to authenticated
with check (public.can_manage_demos());

drop policy if exists "CRM managers can update demo sessions"
on public.demo_sessions;
create policy "CRM managers can update demo sessions"
on public.demo_sessions for update to authenticated
using (public.can_manage_demos())
with check (public.can_manage_demos());

drop policy if exists "CRM managers can delete demo sessions"
on public.demo_sessions;
create policy "CRM managers can delete demo sessions"
on public.demo_sessions for delete to authenticated
using (public.can_manage_demos());

alter table public.demo_attendees enable row level security;

drop policy if exists "CRM users can view demo attendees"
on public.demo_attendees;
create policy "CRM users can view demo attendees"
on public.demo_attendees for select to authenticated
using (public.can_view_crm());

drop policy if exists "CRM managers can create demo attendees"
on public.demo_attendees;
create policy "CRM managers can create demo attendees"
on public.demo_attendees for insert to authenticated
with check (public.can_manage_demos());

drop policy if exists "CRM managers can update demo attendees"
on public.demo_attendees;
create policy "CRM managers can update demo attendees"
on public.demo_attendees for update to authenticated
using (public.can_manage_demos())
with check (public.can_manage_demos());

drop policy if exists "CRM managers can delete demo attendees"
on public.demo_attendees;
create policy "CRM managers can delete demo attendees"
on public.demo_attendees for delete to authenticated
using (public.can_manage_demos());

create or replace function public.grant_orbit_access(
  p_full_name text,
  p_email text,
  p_role text
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_actor_role text;
  v_role text;
  v_email text;
  v_request_id uuid;
  v_existing_user_id uuid;
  v_existing_user_role text;
begin
  if not public.can_manage_access() then
    raise exception 'You do not have permission to grant Orbit access.';
  end if;

  v_actor_role := public.current_orbit_role();
  v_role := public.normalize_access_role(p_role);
  v_email := lower(trim(coalesce(p_email,'')));

  if nullif(trim(coalesce(p_full_name,'')),'') is null then
    raise exception 'Name is required.';
  end if;

  if v_email = '' or position('@' in v_email) < 2 then
    raise exception 'A valid email is required.';
  end if;

  if v_role is null then
    raise exception 'Invalid role.';
  end if;

  if v_actor_role <> 'super_admin' and v_role = 'super_admin' then
    raise exception 'Only a Super Admin can grant Super Admin access.';
  end if;

  select up.id, up.role
  into v_existing_user_id, v_existing_user_role
  from public.user_profiles up
  where lower(trim(coalesce(up.email,''))) = v_email
  order by up.created_at desc
  limit 1;

  if v_actor_role <> 'super_admin'
     and v_existing_user_role = 'super_admin' then
    raise exception 'Only a Super Admin can manage another Super Admin.';
  end if;

  if v_existing_user_id is not null then
    update public.user_profiles
    set
      full_name = coalesce(nullif(trim(p_full_name),''), full_name),
      role = v_role,
      is_active = true,
      updated_at = now()
    where id = v_existing_user_id;
  end if;

  select ar.id into v_request_id
  from public.access_requests ar
  where lower(trim(ar.email)) = v_email
    and ar.status = 'Pending'
  order by ar.created_at desc
  limit 1;

  if v_request_id is not null then
    update public.access_requests
    set
      full_name = trim(p_full_name),
      status = 'Approved',
      approved_role = v_role,
      reviewed_by = auth.uid(),
      reviewed_at = now()
    where id = v_request_id;
  else
    insert into public.access_requests (
      full_name,email,requested_role,approved_role,
      status,reviewed_by,reviewed_at
    )
    values (
      trim(p_full_name),
      v_email,
      case v_role
        when 'super_admin' then 'Super Admin'
        when 'admin' then 'Admin'
        when 'sales' then 'Sales Admin'
        when 'marketing' then 'Marketing'
        when 'trainer' then 'Trainer'
        when 'accounts_finance' then 'Finance Admin'
        else v_role
      end,
      v_role,
      'Approved',
      auth.uid(),
      now()
    )
    returning id into v_request_id;
  end if;

  return v_request_id;
end;
$$;

grant execute on function public.grant_orbit_access(text,text,text)
to authenticated;

create or replace function public.pending_access_request_count()
returns integer
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_count integer;
begin
  if not public.can_manage_access() then
    return 0;
  end if;

  select count(*)::integer into v_count
  from public.access_requests
  where status = 'Pending';

  return coalesce(v_count,0);
end;
$$;

grant execute on function public.pending_access_request_count()
to authenticated;

create or replace function public.delete_access_request(
  p_request_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_request public.access_requests%rowtype;
  v_has_active_user boolean := false;
begin
  if not public.can_manage_access() then
    raise exception 'You do not have permission to remove access requests.';
  end if;

  select * into v_request
  from public.access_requests
  where id = p_request_id;

  if not found then
    raise exception 'Access request not found.';
  end if;

  select exists (
    select 1
    from public.user_profiles up
    where lower(trim(coalesce(up.email,''))) = lower(trim(v_request.email))
      and up.is_active = true
  ) into v_has_active_user;

  if v_request.status = 'Approved' and v_has_active_user then
    raise exception
      'This user is already active. Remove or deactivate them from Orbit Users instead.';
  end if;

  delete from public.access_requests
  where id = p_request_id;
end;
$$;

grant execute on function public.delete_access_request(uuid)
to authenticated;

-- ============================================================
-- END
-- ============================================================
