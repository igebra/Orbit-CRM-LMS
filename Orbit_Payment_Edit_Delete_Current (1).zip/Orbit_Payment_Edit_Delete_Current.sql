-- ============================================================
-- ORBIT PAYMENT EDIT / DELETE WITH CORRECTION AUDIT
-- ============================================================
-- DATABASE CHANGE - ADDITIVE / SAFE
--
-- DOES NOT TOUCH CRM LEADS.
-- DOES NOT ALTER STUDENTS OR BATCH ROSTERS.
-- Existing payments remain unchanged until an authorized user
-- explicitly edits or deletes one.
-- ============================================================

create table if not exists public.payment_transaction_corrections (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null,
  finance_id uuid,
  action text not null check (action in ('EDIT','DELETE')),
  old_amount_usd numeric,
  old_payment_date date,
  old_payment_mode text,
  old_reference text,
  new_amount_usd numeric,
  new_payment_date date,
  new_payment_mode text,
  new_reference text,
  reason text,
  changed_by uuid,
  changed_at timestamptz not null default now()
);

alter table public.payment_transaction_corrections enable row level security;

revoke all on table public.payment_transaction_corrections from anon;
revoke all on table public.payment_transaction_corrections from authenticated;

create or replace function public.update_payment_transaction(
  p_transaction_id uuid,
  p_amount_usd numeric,
  p_payment_date date,
  p_payment_mode text,
  p_reference text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role text;
  v_old public.payment_transactions%rowtype;
begin
  select role into v_role
  from public.user_profiles
  where id = auth.uid();

  if v_role not in (
    'super_admin',
    'admin',
    'sales',
    'sales_marketing',
    'accounts_finance'
  ) then
    raise exception 'You do not have permission to edit payments.';
  end if;

  if p_amount_usd is null or p_amount_usd <= 0 then
    raise exception 'Payment amount must be greater than zero.';
  end if;

  if p_payment_date is null then
    raise exception 'Payment date is required.';
  end if;

  select *
  into v_old
  from public.payment_transactions
  where id = p_transaction_id
  for update;

  if not found then
    raise exception 'Payment transaction not found.';
  end if;

  insert into public.payment_transaction_corrections (
    transaction_id,
    finance_id,
    action,
    old_amount_usd,
    old_payment_date,
    old_payment_mode,
    old_reference,
    new_amount_usd,
    new_payment_date,
    new_payment_mode,
    new_reference,
    changed_by
  )
  values (
    v_old.id,
    v_old.finance_id,
    'EDIT',
    v_old.amount_usd,
    v_old.payment_date,
    v_old.payment_mode,
    v_old.reference,
    p_amount_usd,
    p_payment_date,
    p_payment_mode,
    nullif(trim(coalesce(p_reference,'')),''),
    auth.uid()
  );

  update public.payment_transactions
  set
    amount_usd = p_amount_usd,
    payment_date = p_payment_date,
    payment_mode = p_payment_mode,
    reference = nullif(trim(coalesce(p_reference,'')),'')
  where id = p_transaction_id;
end;
$$;

grant execute on function public.update_payment_transaction(
  uuid,numeric,date,text,text
) to authenticated;


create or replace function public.delete_payment_transaction(
  p_transaction_id uuid,
  p_reason text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role text;
  v_old public.payment_transactions%rowtype;
begin
  select role into v_role
  from public.user_profiles
  where id = auth.uid();

  if v_role not in (
    'super_admin',
    'admin',
    'sales',
    'sales_marketing',
    'accounts_finance'
  ) then
    raise exception 'You do not have permission to delete payments.';
  end if;

  if nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'A deletion reason is required.';
  end if;

  select *
  into v_old
  from public.payment_transactions
  where id = p_transaction_id
  for update;

  if not found then
    raise exception 'Payment transaction not found.';
  end if;

  insert into public.payment_transaction_corrections (
    transaction_id,
    finance_id,
    action,
    old_amount_usd,
    old_payment_date,
    old_payment_mode,
    old_reference,
    reason,
    changed_by
  )
  values (
    v_old.id,
    v_old.finance_id,
    'DELETE',
    v_old.amount_usd,
    v_old.payment_date,
    v_old.payment_mode,
    v_old.reference,
    trim(p_reason),
    auth.uid()
  );

  delete from public.payment_transactions
  where id = p_transaction_id;
end;
$$;

grant execute on function public.delete_payment_transaction(
  uuid,text
) to authenticated;

-- ============================================================
-- END
-- ============================================================
