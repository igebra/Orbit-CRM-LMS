-- ============================================================
-- ORBIT — LMS CLASS FILE STORAGE
-- Private Supabase Storage for class documents.
--
-- Upload to Orbit:
-- PPT / Deck
-- Homework / Worksheet
-- Assessment
-- Reference Material
-- Other class files
--
-- Keep large Zoom recordings external and store their link in
-- class_sessions.zoom_recording_url.
-- ============================================================

create table if not exists public.session_files (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.class_sessions(id) on delete cascade,
  file_type text not null,
  file_name text not null,
  storage_path text not null unique,
  mime_type text,
  size_bytes bigint,
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint session_files_type_check
    check (
      file_type in (
        'PPT / Deck',
        'Homework / Worksheet',
        'Assessment',
        'Reference Material',
        'Other'
      )
    ),
  constraint session_files_size_check
    check (size_bytes is null or size_bytes between 0 and 26214400)
);

create index if not exists session_files_session_id_idx
  on public.session_files(session_id, created_at desc);

alter table public.session_files enable row level security;

drop policy if exists "Orbit LMS files view" on public.session_files;
create policy "Orbit LMS files view"
on public.session_files
for select
to authenticated
using (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_files.session_id
      and public.can_view_batch(cs.batch_id)
  )
);

drop policy if exists "Orbit LMS files insert" on public.session_files;
create policy "Orbit LMS files insert"
on public.session_files
for insert
to authenticated
with check (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_files.session_id
      and public.can_teach_batch(cs.batch_id)
  )
);

drop policy if exists "Orbit LMS files update" on public.session_files;
create policy "Orbit LMS files update"
on public.session_files
for update
to authenticated
using (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_files.session_id
      and public.can_teach_batch(cs.batch_id)
  )
)
with check (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_files.session_id
      and public.can_teach_batch(cs.batch_id)
  )
);

drop policy if exists "Orbit LMS files delete" on public.session_files;
create policy "Orbit LMS files delete"
on public.session_files
for delete
to authenticated
using (
  exists (
    select 1
    from public.class_sessions cs
    where cs.id = session_files.session_id
      and public.can_teach_batch(cs.batch_id)
  )
);

insert into storage.buckets (
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
)
values (
  'lms-files',
  'lms-files',
  false,
  26214400,
  null
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit;

create or replace function public.can_access_lms_file_path(
  p_name text,
  p_manage boolean default false
)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_session_id uuid;
  v_batch_id uuid;
begin
  begin
    v_session_id := split_part(p_name, '/', 1)::uuid;
  exception
    when others then
      return false;
  end;

  select cs.batch_id
  into v_batch_id
  from public.class_sessions cs
  where cs.id = v_session_id;

  if v_batch_id is null then
    return false;
  end if;

  if p_manage then
    return public.can_teach_batch(v_batch_id);
  end if;

  return public.can_view_batch(v_batch_id);
end;
$$;

grant execute on function public.can_access_lms_file_path(text, boolean)
to authenticated;

drop policy if exists "Orbit LMS storage read" on storage.objects;
create policy "Orbit LMS storage read"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'lms-files'
  and public.can_access_lms_file_path(name, false)
);

drop policy if exists "Orbit LMS storage upload" on storage.objects;
create policy "Orbit LMS storage upload"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'lms-files'
  and public.can_access_lms_file_path(name, true)
);

drop policy if exists "Orbit LMS storage update" on storage.objects;
create policy "Orbit LMS storage update"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'lms-files'
  and public.can_access_lms_file_path(name, true)
)
with check (
  bucket_id = 'lms-files'
  and public.can_access_lms_file_path(name, true)
);

drop policy if exists "Orbit LMS storage delete" on storage.objects;
create policy "Orbit LMS storage delete"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'lms-files'
  and public.can_access_lms_file_path(name, true)
);

-- ============================================================
-- END
-- ============================================================
