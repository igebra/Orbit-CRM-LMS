-- ORBIT - BATCH CLASS DAYS
-- DATA SAFE: additive only; no CRM or existing batch data is deleted.

alter table public.batches
  add column if not exists class_days text[] not null default '{}'::text[];

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'batches_class_days_check'
  ) then
    alter table public.batches
      add constraint batches_class_days_check
      check (class_days <@ array['Mon','Tue','Wed','Thu','Fri','Sat','Sun']::text[]);
  end if;
end
$$;

notify pgrst, 'reload schema';
