-- ============================================================
-- ORBIT - REAL CLASSES PER MONTH
-- ============================================================
-- ROOT CAUSE:
-- The Batches page was displaying:
--     classes_per_week * 4
-- so a batch with the old value 1/week always showed 4/month.
-- There was no real classes_per_month column.
--
-- This migration creates a real monthly field.
--
-- DATA SAFETY:
-- - No CRM leads are touched.
-- - No students, batches, sessions, or payments are deleted.
-- - Existing batch records are preserved.
-- ============================================================

alter table public.batches
  add column if not exists classes_per_month integer;

-- Preserve existing values as safely as possible.
-- For Math batches, if a small Planned Sessions value (1-16) was already
-- entered, use it as the initial monthly value. This helps preserve entries
-- such as 8 that were previously being entered for monthly Math frequency.
-- Otherwise fall back to the legacy weekly frequency x 4.
update public.batches
set classes_per_month =
  case
    when course_name ilike 'Math%'
      and planned_sessions between 1 and 16
      then planned_sessions
    else greatest(coalesce(classes_per_week,1) * 4, 1)
  end
where classes_per_month is null;

alter table public.batches
  alter column classes_per_month set default 4;

alter table public.batches
  alter column classes_per_month set not null;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'batches_classes_per_month_check'
  ) then
    alter table public.batches
      add constraint batches_classes_per_month_check
      check (classes_per_month between 1 and 31);
  end if;
end
$$;

notify pgrst, 'reload schema';

-- ============================================================
-- END
-- ============================================================
