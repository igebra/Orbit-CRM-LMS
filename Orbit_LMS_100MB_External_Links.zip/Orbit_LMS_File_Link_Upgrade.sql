-- ============================================================
-- ORBIT LMS — FILE UPLOAD + EXTERNAL LINK SUPPORT
-- ============================================================

alter table public.lms_resources
  add column if not exists external_url text;

alter table public.lms_resources
  drop constraint if exists lms_resources_external_url_check;

alter table public.lms_resources
  add constraint lms_resources_external_url_check
  check (
    external_url is null
    or external_url ~* '^https?://'
  );

create or replace function public.portal_student_resources(
  p_student_id uuid,
  p_for_parent boolean default false
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  if p_for_parent then
    if not public.portal_can_access_student(p_student_id,'parent') then
      raise exception 'Parent access required.';
    end if;
  else
    if not public.portal_can_access_student(p_student_id,'student') then
      raise exception 'Student access required.';
    end if;
  end if;

  select coalesce(
    jsonb_agg(
      item
      order by
        (item->>'class_date')::date desc,
        (item->>'session_number')::int desc
    ),
    '[]'::jsonb
  )
  into v_result
  from (
    select distinct on (lr.id)
      jsonb_build_object(
        'resource_id', lr.id,
        'course_name', b.course_name,
        'session_number', lc.session_number,
        'topic', lc.topic,
        'resource_type', lr.resource_type,
        'title', lr.title,
        'description', lr.description,
        'visibility', lr.visibility,
        'file_name', lv.file_name,
        'storage_path', lv.storage_path,
        'version_number', lv.version_number,
        'external_url', lr.external_url,
        'class_date', cs.session_date
      ) as item,
      lr.id as sort_id
    from public.batch_students bs
    join public.batches b
      on b.id = bs.batch_id
    join public.class_sessions cs
      on cs.batch_id = b.id
     and cs.status = 'Completed'
    join public.lms_curriculum_sessions lc
      on lc.course_name = b.course_name
     and lc.session_number = cs.session_number
    join public.lms_resources lr
      on lr.curriculum_session_id = lc.id
     and lr.is_archived = false
    left join lateral (
      select v.*
      from public.lms_resource_versions v
      where v.resource_id = lr.id
      order by v.version_number desc
      limit 1
    ) lv on true
    where bs.student_id = p_student_id
      and (
        lv.id is not null
        or lr.external_url is not null
      )
      and (
        (
          p_for_parent = true
          and lr.visibility = 'Parent & Student'
        )
        or
        (
          p_for_parent = false
          and lr.visibility in ('Student','Parent & Student')
        )
      )
    order by lr.id, cs.session_date desc
  ) x;

  return v_result;
end;
$$;

grant execute on function public.portal_student_resources(uuid,boolean)
to authenticated;

-- ============================================================
-- END
-- ============================================================
